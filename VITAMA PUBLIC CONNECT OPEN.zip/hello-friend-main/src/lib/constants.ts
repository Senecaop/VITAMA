export const CITATIONS = [
  { text: "Ce que tu fais chaque jour compte plus que ce que tu fais de temps en temps.", auteur: "Gretchen Rubin" },
  { text: "La discipline est choisir entre ce que tu veux maintenant et ce que tu veux le plus.", auteur: "Abraham Lincoln" },
  { text: "Les petites actions répétées créent des résultats extraordinaires.", auteur: "Robin Sharma" },
  { text: "L'intérêt composé est la huitième merveille du monde.", auteur: "Albert Einstein" },
  { text: "Chaque expert a été un jour un débutant.", auteur: "Helen Hayes" },
  { text: "Le succès n'est pas final, l'échec n'est pas fatal : c'est le courage de continuer qui compte.", auteur: "Winston Churchill" },
  { text: "Ne regarde pas l'horloge. Fais ce qu'elle fait — continue.", auteur: "Sam Levenson" },
  { text: "Les habitudes sont le composé de l'amélioration.", auteur: "James Clear" },
  { text: "Ce qui se mesure s'améliore.", auteur: "Peter Drucker" },
  { text: "La clarté vient de l'action, pas de la réflexion.", auteur: "Marie Forleo" },
  { text: "Sois le changement que tu veux voir dans le monde.", auteur: "Gandhi" },
  { text: "Le courage n'est pas l'absence de peur mais la décision que quelque chose d'autre est plus important.", auteur: "Ambrose Redmoon" },
  { text: "Commence là où tu es, utilise ce que tu as, fais ce que tu peux.", auteur: "Arthur Ashe" },
  { text: "La meilleure façon de prédire l'avenir est de le créer.", auteur: "Peter Drucker" },
  { text: "La simplicité est la sophistication suprême.", auteur: "Léonard de Vinci" },
  { text: "L'imagination est plus importante que le savoir.", auteur: "Albert Einstein" },
  { text: "Nul vent n'est favorable pour celui qui ne sait pas où il va.", auteur: "Sénèque" },
  { text: "Ce que tu penses, tu le deviens.", auteur: "Bouddha" },
  { text: "La connaissance sans action est une illusion.", auteur: "Tony Robbins" },
  { text: "Fais de ta vie un rêve et de ton rêve une réalité.", auteur: "Antoine de Saint-Exupéry" },
  { text: "Le succès, c'est aller d'échec en échec sans perdre son enthousiasme.", auteur: "Winston Churchill" },
  { text: "L'échec est le fondement de la réussite.", auteur: "Lao Tseu" },
  { text: "Ta seule limite est toi-même.", auteur: "Anonyme" },
  { text: "Chaque jour est une nouvelle chance de changer ta vie.", auteur: "Anonyme" },
  { text: "Avance. Toujours.", auteur: "Anonyme" },
  { text: "Tu es la moyenne des 5 personnes que tu fréquentes le plus.", auteur: "Jim Rohn" },
  { text: "Ce qui ne te tue pas te rend plus fort.", auteur: "Nietzsche" },
  { text: "Travaille sur toi-même plus que sur ton travail.", auteur: "Jim Rohn" },
  { text: "Deviens la personne que tu aurais voulu rencontrer.", auteur: "Thomas d'Ansembourg" },
  { text: "Le moment de planter un arbre était il y a 20 ans. Le deuxième meilleur moment, c'est maintenant.", auteur: "Proverbe chinois" },
  { text: "Agis comme si ce que tu fais fait une différence. Ça en fait une.", auteur: "William James" },
  { text: "Les personnes qui réussissent ont peur comme tout le monde — elles agissent quand même.", auteur: "George Addair" },
  { text: "Le plus grand risque est de ne prendre aucun risque.", auteur: "Mark Zuckerberg" },
  { text: "Si tu veux aller vite, marche seul. Si tu veux aller loin, marche ensemble.", auteur: "Proverbe africain" },
  { text: "Les petits ruisseaux font les grandes rivières.", auteur: "Proverbe français" },
  { text: "Un homme sage apprend de l'expérience des autres.", auteur: "Voltaire" },
  { text: "Tout voyage commence par un premier pas.", auteur: "Lao Tseu" },
  { text: "Ne limite jamais ce que tu peux faire en limitant ce que tu imagines.", auteur: "James Meredith" },
  { text: "Les grandes choses ne se font jamais dans le confort.", auteur: "Anonyme" },
  { text: "Investis en toi-même. Ta carrière est le moteur de ta richesse.", auteur: "Paul Clitheroe" },
  { text: "L'action est le fondement de tout succès.", auteur: "Pablo Picasso" },
  { text: "Ton attitude, pas ton aptitude, détermine ton altitude.", auteur: "Zig Ziglar" },
  { text: "Si tu te bats pour quelque chose, tu te bats pour toi.", auteur: "Anonyme" },
  { text: "Ce que l'on sème, on le récolte — toujours, sans exception.", auteur: "Anonyme" },
  { text: "Vis comme si tu devais mourir demain. Apprends comme si tu devais vivre toujours.", auteur: "Gandhi" },
  { text: "Tu n'as pas à être extraordinaire pour commencer, mais tu dois commencer pour être extraordinaire.", auteur: "Zig Ziglar" },
  { text: "La vie est trop courte pour être petite.", auteur: "Benjamin Disraeli" },
  { text: "Chaque matin tu as deux choix : continuer à dormir avec tes rêves, ou te lever et les réaliser.", auteur: "Anonyme" },
  { text: "Une vie non examinée ne vaut pas la peine d'être vécue.", auteur: "Socrate" },
  { text: "Le secret du changement est de concentrer toute ton énergie à construire le nouveau.", auteur: "Socrate" },
];

export const XP_THRESHOLDS = Array.from({ length: 100 }, (_, i) => (i + 1) * (i + 1) * 60);

export const getLevel = (xp: number): number => {
  let l = 1;
  for (let i = 0; i < XP_THRESHOLDS.length; i++) {
    if (xp >= XP_THRESHOLDS[i]) l = i + 2;
    else break;
  }
  return Math.min(l, 100);
};

export const xpForLevel = (l: number): number => l <= 1 ? 0 : XP_THRESHOLDS[l - 2];
export const xpToNext = (l: number): number => XP_THRESHOLDS[Math.min(l - 1, 98)];

const LEVEL_NAMES = ["Novice", "Apprenti", "Pratiquant", "Habitué", "Régulier", "Discipliné", "Déterminé", "Focused", "Puissant", "Maître", "Visionnaire", "Légende"];
export const getLevelName = (l: number): string => LEVEL_NAMES[Math.min(Math.floor((l - 1) / 9), LEVEL_NAMES.length - 1)];

export const JOURS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
export const JOURS_SHORT = ["Lu", "Ma", "Me", "Je", "Ve", "Sa", "Di"];

export const todayStr = (): string => new Date().toISOString().split("T")[0];

export const weekMonday = (): string => {
  const d = new Date();
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d.toISOString().split("T")[0];
};

export const getAutoTheme = (): string => {
  const h = new Date().getHours();
  return h >= 7 && h < 19 ? "light" : "dark";
};

export const greeting = (name?: string): string => {
  const h = new Date().getHours();
  const g = h < 6 ? "Bonne nuit" : h < 12 ? "Bonjour" : h < 18 ? "Bon après-midi" : "Bonsoir";
  return name ? `${g}, ${name}` : g;
};

export const citeDuJour = () => CITATIONS[Math.floor(Date.now() / 86400000) % CITATIONS.length];

export const IC: Record<string, string> = {
  home: "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z M9 22V12h6v10",
  books: "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z",
  target: "M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zM12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4z",
  lock: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  quote: "M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1zm12 0c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z",
  plus: "M12 5v14M5 12h14",
  trash: "M3 6h18M19 6l-1 14H6L5 6M9 6V4h6v2",
  back: "M19 12H5M12 19l-7-7 7-7",
  close: "M18 6L6 18M6 6l12 12",
  eye: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z",
  eyeoff: "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22",
  copy: "M20 9H11a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2zM5 15H4a2 2 0 0 0-2 2v-9a2 2 0 0 0 2-2h9a2 2 0 0 0 2 2v1",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  check: "M20 6L9 17l-5-5",
  star: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  flame: "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",
  search: "M21 21l-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0z",
  sun: "M12 17A5 5 0 1 0 12 7a5 5 0 0 0 0 10zM12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42",
  moon: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z",
  repeat: "M17 1l4 4-4 4M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 0 1-4 4H3",
  chart: "M18 20V10M12 20V4M6 20v-6",
  user: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  ai: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM8 12h8M12 8v8",
  journal: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M16 13H8M16 17H8M10 9H8",
  timer: "M10 2h4M12 14l-2-2M12 6a8 8 0 1 0 0 16 8 8 0 0 0 0-16z",
  bolt: "M13 2L3 14h9l-1 8 10-12h-9l1-8z",
  award: "M12 15l-3.09 6.26L12 18.27l3.09 3-1.18-6.88L19 9.27l-6.91-1.01L12 2 9.09 8.26 2 9.27l5 4.87z",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  heart: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
  video: "M15 10l4.553-2.276A1 1 0 0 1 21 8.723v6.554a1 1 0 0 1-1.447.894L15 14M3 8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8z",
  link: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",
  filter: "M22 3H2l8 9.46V19l4 2v-8.54L22 3z",
  externalLink: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3",
};

export const MOODS = [
  { e: "🪫", l: "Épuisé" },
  { e: "😔", l: "Difficile" },
  { e: "😐", l: "Neutre" },
  { e: "😊", l: "Bien" },
  { e: "🔥", l: "Au sommet" },
];

export const AVATARS = ["🌿", "🔥", "⚡", "🦁", "🐺", "🦋", "🌊", "⭐", "🎯", "💎", "🌙", "☀️", "🍃", "🧠", "🚀"];

export const BLOCS = [
  { key: "matin", label: "Matin", sub: "6h–12h", emoji: "☀️", color: "hsl(var(--honey))" },
  { key: "apmidi", label: "Après-midi", sub: "12h–18h", emoji: "🌤", color: "hsl(var(--olive))" },
  { key: "soir", label: "Soir", sub: "18h–23h", emoji: "🌙", color: "hsl(var(--bark2))" },
];

export const NAV_GROUPS = [
  { label: "Principal", items: [{ id: "home", label: "Accueil", emoji: "🏠" }, { id: "dashboard", label: "Dashboard", emoji: "📊" }] },
  { label: "Quotidien", items: [{ id: "agenda", label: "Agenda", emoji: "📅" }, { id: "journal", label: "Journal", emoji: "✍️" }, { id: "tasks", label: "Tasks", emoji: "⭕" }] },
  { label: "Croissance", items: [{ id: "habitudes", label: "Habitudes", emoji: "🔁" }, { id: "suivi", label: "Suivi", emoji: "🎯" }] },
  { label: "Espace", items: [{ id: "library", label: "Bibliothèque", emoji: "📚" }, { id: "citations", label: "Citations", emoji: "✨" }] },
  { label: "Stratégie", items: [{ id: "videos", label: "À regarder", emoji: "🎬" }] },
];

export const JOURNAL_QUESTIONS = [
  "Quelle est ma grande priorité d'aujourd'hui ?",
  "Comment je me sens en ce moment, vraiment ?",
  "Qu'est-ce qui m'a le plus avancé hier ?",
  "De quoi je suis reconnaissant aujourd'hui ?",
  "Quelle habitude je veux renforcer cette semaine ?",
];

export const HAB_EMOJIS = ["💪", "📖", "🧘", "🏃", "💧", "🥗", "😴", "✍️", "🎯", "🧠", "🌅", "🎵", "💻", "🌿", "🔥"];
export const HAB_COLORS = ["hsl(88, 30%, 23%)", "hsl(38, 85%, 31%)", "hsl(150, 35%, 28%)", "hsl(340, 65%, 55%)", "hsl(200, 50%, 45%)", "hsl(280, 35%, 55%)"];
export const EMOJIS = ["📖", "🌙", "🔥", "💡", "🎯", "💻", "🧠", "✨", "🌱", "🎨", "📝", "🏆", "🚀", "💎", "🌸", "🍃", "🦋", "🌊", "⭐", "🎵"];
