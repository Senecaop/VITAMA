// ═══ STORAGE MULTI-COMPTE PAR MOT DE PASSE ═══
// Chaque mot de passe = un compte unique.
// Les données sont namespaced sous le hash du mot de passe.
// Personne ne peut voir le mot de passe des autres.

let _accountKey = "";

const prefix = (key: string) => `vitama-${_accountKey}-${key}`;

export const db = {
  setAccount(key: string) { _accountKey = key; },
  getAccount(): string { return _accountKey; },

  async get<T = any>(key: string): Promise<T | null> {
    try {
      const raw = localStorage.getItem(prefix(key));
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  },

  async set(key: string, value: any): Promise<void> {
    try { localStorage.setItem(prefix(key), JSON.stringify(value)); } catch {}
  },

  async del(key: string): Promise<void> {
    try { localStorage.removeItem(prefix(key)); } catch {}
  },
};

// ═══ GESTION DES COMPTES ═══
// Les comptes = liste des hash de mots de passe connus.
const ACCOUNTS_KEY = "vitama-known-accounts";

async function hashPwd(pwd: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(pwd));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function loadAccounts(): string[] {
  try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "[]"); }
  catch { return []; }
}

function saveAccounts(list: string[]) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(list));
}

export const auth = {
  hasAnyAccount(): boolean {
    return loadAccounts().length > 0;
  },

  // Vérifie si un mot de passe correspond à un compte existant
  async tryLogin(pwd: string): Promise<string | null> {
    const hash = await hashPwd(pwd);
    const accounts = loadAccounts();
    if (accounts.includes(hash)) return hash;
    return null;
  },

  // Crée un nouveau compte avec ce mot de passe
  async register(pwd: string): Promise<string> {
    const hash = await hashPwd(pwd);
    const accounts = loadAccounts();
    if (!accounts.includes(hash)) {
      accounts.push(hash);
      saveAccounts(accounts);
    }
    return hash;
  },
};
