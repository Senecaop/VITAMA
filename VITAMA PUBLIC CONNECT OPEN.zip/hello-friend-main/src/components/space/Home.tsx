import { useState, useEffect, useRef } from "react";
import { AreaChart, Area, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { db } from "@/lib/storage";
import { todayStr, greeting, citeDuJour, MOODS, JOURS, IC } from "@/lib/constants";
import { StatCard, XpBar, Ic, Ring } from "./BaseUI";
import { OrganicCanvas, GlitterCanvas } from "./Canvas";
import { useTheme, useXP, useToast } from "@/contexts/AppContext";

export const Home = ({ onNav, profile }: { onNav: (p: string) => void; profile: { prenom: string; avatar: string } }) => {
  const { theme } = useTheme();
  const { xp, level, addXP } = useXP();
  const { showToast } = useToast();
  const isGirls = theme === "girls";

  const [books, setBooks] = useState<any[]>([]);
  const [objectifs, setObjectifs] = useState<any[]>([]);
  const [streak, setStreak] = useState(0);
  const [mood, setMood] = useState<number | null>(null);
  const [qnote, setQnote] = useState("");
  const [noteSaved, setNoteSaved] = useState(false);
  const [habitudes, setHabitudes] = useState<any[]>([]);
  const [agendaToday, setAgendaToday] = useState<any>(null);
  const noteTimer = useRef<any>(null);
  const cit = citeDuJour();
  const dateStr = new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });

  useEffect(() => {
    db.get("lib-books").then(b => setBooks(b || []));
    db.get("objectifs").then(o => setObjectifs(o || []));
    db.get("habitudes").then(h => setHabitudes(h || []));
    db.get(`mood-${todayStr()}`).then(m => setMood(m));
    db.get(`qnote-${todayStr()}`).then(n => setQnote(n || ""));
    db.get(`agenda-${todayStr()}`).then(a => setAgendaToday(a));
    db.get("streak").then(s => {
      if (!s) { db.set("streak", { count: 1, last: todayStr() }); setStreak(1); return; }
      const diff = Math.floor((new Date(todayStr()).getTime() - new Date(s.last).getTime()) / 86400000);
      if (diff === 0) setStreak(s.count);
      else if (diff === 1) { const ns = { count: s.count + 1, last: todayStr() }; db.set("streak", ns); setStreak(ns.count); }
      else { db.set("streak", { count: 1, last: todayStr() }); setStreak(1); }
    });
  }, []);

  const setMoodForDay = async (m: number) => { setMood(m); await db.set(`mood-${todayStr()}`, m); addXP(5, "Humeur enregistrée", "mood"); };
  const saveNote = (val: string) => { setQnote(val); setNoteSaved(false); clearTimeout(noteTimer.current); noteTimer.current = setTimeout(async () => { await db.set(`qnote-${todayStr()}`, val); setNoteSaved(true); }, 650); };

  const totalCases = objectifs.reduce((a: number, o: any) => a + (o.jours || []).reduce((b: number, j: any) => b + j.cases.filter((c: any) => c.checked).length, 0), 0);
  const urgentTasks = agendaToday ? Object.values(agendaToday).flat().filter((t: any) => !t.done).slice(0, 3) : [];

  const weekData = JOURS.map((j, i) => { let done = 0, total = 0; objectifs.forEach((o: any) => { const jour = o.jours?.[i]; if (!jour) return; done += jour.cases.filter((c: any) => c.checked).length; total += jour.cases.length; }); return { j: j.slice(0, 2), done, total, pct: total ? Math.round(done / total * 100) : 0 }; });
  const activeDays = weekData.filter(d => d.total > 0);
  const avgPct = activeDays.length ? Math.round(activeDays.reduce((a, d) => a + d.pct, 0) / activeDays.length) : 0;
  const hasChart = weekData.some(d => d.total > 0);

  const insight = streak >= 30 ? `🏆 ${streak} jours d'affilée. Tu fais partie du top 1%.` : streak >= 14 ? `🔥 ${streak} jours de suite — la discipline est devenue identité.` : avgPct >= 80 ? `💎 ${avgPct}% complétés cette semaine — cap maintenu.` : habitudes.length ? `🌱 ${habitudes.length} habitude${habitudes.length > 1 ? "s" : ""} actives. L'effort composé construit ta version future.` : `🌿 ${streak} jour${streak > 1 ? "s" : ""} présent. La régularité bat l'intensité.`;

  const TT = ({ active, payload }: any) => { if (!active || !payload?.length) return null; const d = payload[0]?.payload; return <div style={{ background: "hsl(var(--bark2))", padding: "8px 14px", borderRadius: 6, fontSize: 12, boxShadow: "var(--sh-lg)" }}><p style={{ color: "rgba(240,232,216,.55)", marginBottom: 3 }}>{d.j}</p><p style={{ color: "hsl(var(--honey-lt))", fontWeight: 700 }}>{d.done} tâche{d.done !== 1 ? "s" : ""}</p></div>; };

  return (
    <div className="scale-in">
      {/* Greeting */}
      <div className="rise" style={{ marginBottom: 26, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div>
          <p style={{ fontSize: 11, color: "hsl(var(--muted))", marginBottom: 4, textTransform: "capitalize", letterSpacing: ".03em" }}>{dateStr}</p>
          <h1 className={isGirls ? "cg-i shimmer-text" : "cg-i"} style={{ fontSize: 36, color: isGirls ? undefined : "hsl(var(--bark))", lineHeight: 1.15, fontWeight: 500 }}>{greeting(profile?.prenom)}</h1>
        </div>
        <div style={{ flexShrink: 0, textAlign: "center" }}>
          <div className="float" style={{ fontSize: 40, opacity: 0.75 }}>{profile?.avatar || "🌿"}</div>
          <div style={{ fontSize: 10, color: "hsl(var(--honey))", fontWeight: 600, marginTop: 3 }}>Niv.{level}</div>
        </div>
      </div>

      {/* Stats */}
      <div className="rise s1" style={{ display: "flex", gap: 11, marginBottom: 18, flexWrap: "wrap" }}>
        <StatCard emoji="🔥" val={streak} label={`Jour${streak !== 1 ? "s" : ""} de suite`} color="hsl(var(--honey))" delay={1} onNav={onNav} />
        <StatCard emoji="✅" val={totalCases} label="Actions" color="hsl(var(--olive))" delay={2} to="suivi" onNav={onNav} />
        <StatCard emoji="🔁" val={habitudes.length} label="Habitudes" color="hsl(var(--honey))" delay={3} to="habitudes" onNav={onNav} />
        <StatCard emoji="📚" val={books.length} label="Livres" color="hsl(var(--olive))" delay={4} to="library" onNav={onNav} />
      </div>

      {/* XP bar */}
      <div className="rise s2" style={{ marginBottom: 18 }}>
        <XpBar xp={xp} level={level} />
      </div>

      {/* Insight */}
      <div className="rise s2" style={{ background: "hsla(var(--olive), 0.1)", borderRadius: 10, padding: "14px 18px", marginBottom: 16, borderLeft: "3px solid hsl(var(--olive))", border: "1.5px solid hsla(var(--olive), 0.1)", borderLeftWidth: "3px", cursor: "pointer", transition: "all .2s" }}
        onClick={() => onNav("ia")}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <Ic d={IC.ai} size={14} color="hsl(var(--olive))" />
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--olive))", textTransform: "uppercase", letterSpacing: ".07em" }}>Insight IA</p>
          <span style={{ marginLeft: "auto", fontSize: 11, color: "hsl(var(--muted))" }}>Ouvrir l'IA →</span>
        </div>
        <p style={{ fontSize: 13.5, color: "hsl(var(--bark2))", lineHeight: 1.8 }}>{insight}</p>
      </div>

      {/* Urgent tasks */}
      {urgentTasks.length > 0 && <div className="rise s3" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "14px 18px", marginBottom: 16, boxShadow: "var(--sh-xs)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em" }}>Tâches urgentes</p>
          <button onClick={() => onNav("agenda")} style={{ fontSize: 12, color: "hsl(var(--honey))", fontWeight: 600 }}>Tout voir →</button>
        </div>
        {urgentTasks.map((t: any, i: number) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", borderBottom: i < urgentTasks.length - 1 ? "1px solid hsl(var(--surface2))" : "none" }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: "hsl(var(--honey))", flexShrink: 0 }} />
          <span style={{ fontSize: 13, color: "hsl(var(--foreground))" }}>{t.txt}</span>
        </div>)}
      </div>}

      {/* Chart */}
      <div className="rise s3" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "16px 20px", marginBottom: 14, boxShadow: "var(--sh-xs)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em" }}>Semaine en cours</p>
          {hasChart && <span style={{ fontSize: 12, fontWeight: 700, color: avgPct >= 80 ? "hsl(var(--green))" : avgPct >= 50 ? "hsl(var(--honey))" : "hsl(var(--muted2))", background: avgPct >= 80 ? "hsla(var(--olive), 0.1)" : avgPct >= 50 ? "hsla(var(--honey), 0.1)" : "hsl(var(--surface2))", padding: "3px 8px", borderRadius: 4 }}>{avgPct}%</span>}
        </div>
        {hasChart ? <ResponsiveContainer width="100%" height={78}><AreaChart data={weekData} margin={{ top: 4, right: 4, bottom: 0, left: -32 }}>
          <defs><linearGradient id="hg4" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="hsl(var(--honey))" stopOpacity={0.18} /><stop offset="95%" stopColor="hsl(var(--honey))" stopOpacity={0} /></linearGradient></defs>
          <XAxis dataKey="j" tick={{ fontSize: 11, fill: "hsl(var(--muted))" }} axisLine={false} tickLine={false} />
          <Tooltip content={<TT />} cursor={{ stroke: "hsl(var(--border2))", strokeWidth: 1 }} />
          <Area type="monotone" dataKey="done" stroke="hsl(var(--honey))" strokeWidth={2.5} fill="url(#hg4)" dot={{ fill: "hsl(var(--honey))", r: 3, strokeWidth: 0 }} activeDot={{ r: 4.5, fill: "hsl(var(--honey))", strokeWidth: 2, stroke: "hsl(var(--surface))" }} />
        </AreaChart></ResponsiveContainer> : <div style={{ height: 68, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(var(--muted2))", fontSize: 13, fontStyle: "italic" }}>Ajoute des objectifs pour visualiser ta semaine</div>}
      </div>

      {/* Mood + note */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
        <div className="rise s4" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "14px 16px", boxShadow: "var(--sh-xs)" }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 10 }}>Énergie</p>
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
            {MOODS.map((m, i) => <button key={i} onClick={() => setMoodForDay(i)} title={m.l} style={{ fontSize: 20, padding: "5px 7px", borderRadius: 6, background: mood === i ? "hsla(var(--honey), 0.1)" : "transparent", border: mood === i ? "1.5px solid hsla(var(--honey), 0.35)" : "1.5px solid transparent", transform: mood === i ? "scale(1.15)" : "scale(1)", transition: "all .2s" }}>{m.e}</button>)}
          </div>
          {mood !== null && <p style={{ fontSize: 11, color: "hsl(var(--honey))", fontWeight: 600, marginTop: 8 }}>{MOODS[mood]?.l}</p>}
        </div>
        <div className="rise s4" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, overflow: "hidden", boxShadow: "var(--sh-xs)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 14px", borderBottom: "1px solid hsl(var(--border))" }}>
            <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em" }}>Note du jour</p>
            <span style={{ fontSize: 10, fontWeight: 600, color: noteSaved ? "hsl(var(--green))" : qnote ? "hsl(var(--honey))" : "hsl(var(--muted2))" }}>{noteSaved ? "✓" : qnote ? "…" : ""}</span>
          </div>
          <textarea value={qnote} onChange={e => saveNote(e.target.value)} placeholder="Une pensée, une intention…" rows={3} style={{ border: "none", borderRadius: 0, boxShadow: "none", padding: "10px 14px", fontSize: 13, background: "transparent", resize: "none", lineHeight: 1.8 }} />
        </div>
      </div>

      {/* Citation */}
      <div className="rise s5 grain" style={{ background: isGirls ? "linear-gradient(160deg, hsl(340, 40%, 8%), hsl(350, 35%, 14%))" : "linear-gradient(160deg, #0a0704, #1e140a)", borderRadius: 10, padding: "20px 24px", position: "relative", overflow: "hidden" }}>
        {isGirls ? <GlitterCanvas style={{ opacity: 0.5 }} /> : <OrganicCanvas style={{ opacity: 0.45 }} />}
        <Ic d={IC.quote} size={16} color={isGirls ? "rgba(220,100,160,.3)" : "rgba(200,150,50,.3)"} />
        <p style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic", fontSize: 16, color: isGirls ? "#f8d7e8" : "#f0e8d8", lineHeight: 1.85, marginTop: 10, marginBottom: 10 }}>"{cit.text}"</p>
        <p style={{ fontSize: 12, color: isGirls ? "rgba(220,100,160,.65)" : "rgba(200,150,50,.65)", fontWeight: 500 }}>— {cit.auteur}</p>
      </div>
    </div>
  );
};
