import { useState, useEffect, useRef } from "react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer } from "recharts";
import { db } from "@/lib/storage";
import { todayStr, JOURS, BLOCS, JOURNAL_QUESTIONS, CITATIONS, MOODS, IC, HAB_EMOJIS, HAB_COLORS, EMOJIS, PWD_EMOJIS, citeDuJour } from "@/lib/constants";
import { Btn, Ic, Field, Modal, Ring, XpBar, PwdStrength, useConfirm } from "./BaseUI";
import { OrganicCanvas } from "./Canvas";
import { useXP, useToast } from "@/contexts/AppContext";

// ═══ DASHBOARD ═══
export const Dashboard = ({ onNav }: { onNav: (p: string) => void }) => {
  const { xp, level } = useXP();
  const [data, setData] = useState<any>(null);
  const [moodHist, setMoodHist] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([db.get("lib-books"), db.get("objectifs"), db.get("passwords"), db.get("habitudes"), db.get("streak")]).then(([books, objectifs, passwords, habitudes, streak]) => {
      const objs = objectifs || []; const habs = habitudes || [];
      const totalActions = objs.reduce((a: number, o: any) => (o.jours || []).reduce((b: number, j: any) => b + j.cases.filter((c: any) => c.checked).length, 0) + a, 0);
      const totalTasks = objs.reduce((a: number, o: any) => (o.jours || []).reduce((b: number, j: any) => b + j.cases.length, 0) + a, 0);
      const habitDone = habs.reduce((a: number, h: any) => a + (h.jours || []).filter(Boolean).length, 0);
      const habitTotal = habs.length * 7;
      setData({
        books: (books || []).length, passwords: (passwords || []).length, streak: streak?.count || 0,
        totalActions, totalTasks, pctActions: totalTasks ? Math.round(totalActions / totalTasks * 100) : 0,
        habitudes: habs.length, habitDone, habitTotal, pctHabits: habitTotal ? Math.round(habitDone / habitTotal * 100) : 0,
        radarData: [
          { s: "Objectifs", v: totalTasks ? Math.round(totalActions / totalTasks * 100) : 0 },
          { s: "Habitudes", v: habitTotal ? Math.round(habitDone / habitTotal * 100) : 0 },
          { s: "Présence", v: Math.min((streak?.count || 0) * 10, 100) },
          { s: "Bibliothèque", v: Math.min((books || []).length * 15, 100) },
        ],
      });
    });
    const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 6 + i); return d.toISOString().split("T")[0]; });
    Promise.all(days.map(d => db.get(`mood-${d}`).then(m => ({ d, m })))).then(setMoodHist);
  }, []);

  if (!data) return <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 280 }}><div style={{ width: 28, height: 28, borderRadius: "50%", border: "2.5px solid hsl(var(--border2))", borderTopColor: "hsl(var(--honey))", animation: "spin 1s linear infinite" }} /></div>;
  const MS = ["🪫", "😔", "😐", "😊", "🔥"];

  return (
    <div className="scale-in">
      <div className="rise" style={{ marginBottom: 24 }}>
        <h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Dashboard</h2>
        <p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>Vue globale — OS personnel</p>
      </div>
      <div className="rise s1" style={{ marginBottom: 16 }}><XpBar xp={xp} level={level} /></div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginBottom: 16 }}>
        {[{ e: "🔥", v: data.streak, l: "Streak", c: "hsl(var(--honey))" }, { e: "✅", v: data.totalActions, l: "Actions", c: "hsl(var(--olive))" }, { e: "🔁", v: data.habitudes, l: "Habitudes", c: "hsl(var(--honey))" }, { e: "📚", v: data.books, l: "Livres", c: "hsl(var(--olive))" }].map((s, i) => (
          <div key={i} className={`rise s${i + 1}`} style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "14px 16px", boxShadow: "var(--sh-xs)" }}>
            <div style={{ fontSize: 18, marginBottom: 6 }}>{s.e}</div>
            <div style={{ fontSize: 24, fontWeight: 700, color: s.c, lineHeight: 1 }}>{s.v}</div>
            <div style={{ fontSize: 11, color: "hsl(var(--muted))", marginTop: 4 }}>{s.l}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
        <div className="rise s2" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "16px 14px", boxShadow: "var(--sh-xs)" }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 6 }}>Performance</p>
          <ResponsiveContainer width="100%" height={160}>
            <RadarChart data={data.radarData}><PolarGrid stroke="hsl(var(--border))" strokeOpacity={0.5} /><PolarAngleAxis dataKey="s" tick={{ fontSize: 10, fill: "hsl(var(--muted))" }} /><Radar dataKey="v" stroke="hsl(var(--honey))" fill="hsl(var(--honey))" fillOpacity={0.1} strokeWidth={2} /></RadarChart>
          </ResponsiveContainer>
        </div>
        <div className="rise s3" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "16px 14px", boxShadow: "var(--sh-xs)" }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 12 }}>Énergie — 7 jours</p>
          {moodHist.map(({ d, m }: any, i: number) => { const dow = new Date(d + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "short" }); return <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 10, color: d === todayStr() ? "hsl(var(--honey))" : "hsl(var(--muted))", width: 24, fontWeight: d === todayStr() ? 700 : 400, textTransform: "capitalize" }}>{dow}</span>
            <div style={{ flex: 1, height: 4, background: "hsl(var(--surface2))", borderRadius: 2, overflow: "hidden" }}><div style={{ height: "100%", width: m !== null ? `${(m + 1) * 20}%` : "0%", background: m === 4 ? "hsl(var(--green))" : m >= 3 ? "hsl(var(--olive))" : "hsl(var(--honey))", borderRadius: 2, transition: "width .5s" }} /></div>
            <span style={{ fontSize: 16 }}>{m !== null ? MS[m] : "·"}</span>
          </div>; })}
        </div>
      </div>
      <div className="rise s4" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "16px 20px", boxShadow: "var(--sh-xs)" }}>
        <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 14 }}>Taux de complétion</p>
        {[{ l: "Objectifs", v: data.pctActions, n: `${data.totalActions}/${data.totalTasks}`, c: "hsl(var(--olive))" }, { l: "Habitudes", v: data.pctHabits, n: `${data.habitDone}/${data.habitTotal}`, c: "hsl(var(--honey))" }].map((r, i) => (
          <div key={i} style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 13, color: "hsl(var(--foreground))" }}>{r.l}</span>
              <span style={{ fontSize: 12, fontWeight: 600, color: r.v >= 80 ? "hsl(var(--green))" : r.v >= 50 ? "hsl(var(--honey))" : "hsl(var(--muted2))" }}>{r.n} — {r.v}%</span>
            </div>
            <div style={{ height: 5, background: "hsl(var(--surface2))", borderRadius: 3, overflow: "hidden" }}><div style={{ height: "100%", width: `${r.v}%`, background: r.c, borderRadius: 3, transition: "width .7s cubic-bezier(.22,1,.36,1)" }} /></div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ═══ AGENDA ═══
export const Agenda = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [date, setDate] = useState(todayStr());
  const [data, setData] = useState<Record<string, any[]>>({ matin: [], apmidi: [], soir: [] });
  const [inputs, setInputs] = useState<Record<string, string>>({ matin: "", apmidi: "", soir: "" });

  useEffect(() => { db.get(`agenda-${date}`).then(d => setData(d || { matin: [], apmidi: [], soir: [] })); }, [date]);
  const save = async (d: any) => { setData(d); await db.set(`agenda-${date}`, d); };
  const addTask = async (bloc: string) => { const txt = inputs[bloc].trim(); if (!txt) return; await save({ ...data, [bloc]: [...data[bloc], { id: Date.now(), txt, done: false }] }); setInputs(i => ({ ...i, [bloc]: "" })); };
  const toggle = async (bloc: string, id: number) => { const upd = { ...data, [bloc]: data[bloc].map(t => t.id === id ? { ...t, done: !t.done } : t) }; await save(upd); const t = upd[bloc].find((x: any) => x.id === id); if (t?.done) addXP(5, "Tâche ✓", "task-" + id); };
  const delTask = async (bloc: string, id: number) => { const ok = await ask("Supprimer cette tâche ?"); if (ok) save({ ...data, [bloc]: data[bloc].filter(t => t.id !== id) }); };
  const navDay = (d: number) => { const nd = new Date(date); nd.setDate(nd.getDate() + d); setDate(nd.toISOString().split("T")[0]); };
  const isToday = date === todayStr();
  const totalDone = Object.values(data).flat().filter(t => t.done).length;
  const totalAll = Object.values(data).flat().length;

  return (
    <div className="scale-in">
      {ConfirmDialog}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div className="rise"><h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Agenda</h2><p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>Organise ta journée</p></div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button onClick={() => navDay(-1)} style={{ padding: "7px 10px", borderRadius: 6, border: "1.5px solid hsl(var(--border))", color: "hsl(var(--muted))", background: "hsl(var(--surface))" }}>←</button>
          <button onClick={() => setDate(todayStr())} style={{ padding: "6px 12px", borderRadius: 6, border: "1.5px solid", borderColor: isToday ? "hsl(var(--honey))" : "hsl(var(--border))", background: isToday ? "hsla(var(--honey), 0.1)" : "hsl(var(--surface))", color: isToday ? "hsl(var(--honey))" : "hsl(var(--muted))", fontSize: 12, fontWeight: 600 }}>Aujourd'hui</button>
          <button onClick={() => navDay(1)} style={{ padding: "7px 10px", borderRadius: 6, border: "1.5px solid hsl(var(--border))", color: "hsl(var(--muted))", background: "hsl(var(--surface))" }}>→</button>
        </div>
      </div>
      {totalAll > 0 && <div className="rise s1" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "12px 18px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12, boxShadow: "var(--sh-xs)" }}>
        <Ring value={totalDone} max={totalAll || 1} size={48} stroke={4} color={totalDone === totalAll ? "hsl(var(--green))" : "hsl(var(--honey))"} label={`${totalAll ? Math.round(totalDone / totalAll * 100) : 0}%`} />
        <div><p style={{ fontWeight: 600, color: "hsl(var(--bark))", fontSize: 15, textTransform: "capitalize" }}>{new Date(date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</p><p style={{ fontSize: 12, color: "hsl(var(--muted))" }}>{totalDone}/{totalAll} tâches</p></div>
      </div>}
      {BLOCS.map((bloc, bi) => (
        <div key={bloc.key} className={`rise s${bi + 2}`} style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <span style={{ fontSize: 16 }}>{bloc.emoji}</span>
            <p style={{ fontSize: 12, fontWeight: 600, color: "hsl(var(--bark))" }}>{bloc.label}</p>
            <span style={{ fontSize: 11, color: "hsl(var(--muted))" }}>{bloc.sub}</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 5, marginBottom: 8 }}>
            {data[bloc.key]?.map((t: any) => (
              <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 9, background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 8, padding: "9px 14px", transition: "all .2s" }}>
                <input type="checkbox" checked={t.done} onChange={() => toggle(bloc.key, t.id)} />
                <span style={{ flex: 1, fontSize: 13, color: t.done ? "hsl(var(--muted2))" : "hsl(var(--foreground))", textDecoration: t.done ? "line-through" : "none" }}>{t.txt}</span>
                <button onClick={() => delTask(bloc.key, t.id)} style={{ color: "hsl(var(--muted2))", padding: 3 }}><Ic d={IC.close} size={12} /></button>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 7 }}>
            <input placeholder={`+ ${bloc.label}…`} value={inputs[bloc.key] || ""} onChange={e => setInputs(i => ({ ...i, [bloc.key]: e.target.value }))} onKeyDown={e => e.key === "Enter" && addTask(bloc.key)} style={{ fontSize: 13 }} />
            <button onClick={() => addTask(bloc.key)} style={{ background: bloc.color, color: "hsl(var(--background))", borderRadius: 6, padding: "0 13px", fontWeight: 700, fontSize: 15, flexShrink: 0 }}>+</button>
          </div>
        </div>
      ))}
    </div>
  );
};

// ═══ JOURNAL ═══
export const Journal = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [entries, setEntries] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);
  const [date, setDate] = useState(todayStr());
  const timer = useRef<any>(null);

  useEffect(() => { db.get(`journal-${date}`).then(d => setEntries(d || {})); }, [date]);

  const save = async (e: Record<number, string>) => { setSaving(true); clearTimeout(timer.current); timer.current = setTimeout(async () => { await db.set(`journal-${date}`, e); setSaving(false); const filled = Object.values(e).filter(v => v.trim()).length; if (filled === JOURNAL_QUESTIONS.length) { addXP(25, "Journal complété !", "journal-" + date); showToast("Journal du jour complété ✓"); } }, 600); };
  const update = async (i: number, val: string) => { const e = { ...entries, [i]: val }; setEntries(e); await save(e); };
  const navDay = (delta: number) => { const d = new Date(date); d.setDate(d.getDate() + delta); setDate(d.toISOString().split("T")[0]); };
  const filled = Object.values(entries).filter(v => v && v.trim()).length;
  const isToday = date === todayStr();

  return (
    <div className="scale-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div className="rise"><h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Journal</h2><p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>5 questions guidées par jour</p></div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button onClick={() => navDay(-1)} style={{ padding: "7px 10px", borderRadius: 6, border: "1.5px solid hsl(var(--border))", color: "hsl(var(--muted))", background: "hsl(var(--surface))" }}>←</button>
          <button onClick={() => setDate(todayStr())} style={{ padding: "6px 12px", borderRadius: 6, border: "1.5px solid", borderColor: isToday ? "hsl(var(--honey))" : "hsl(var(--border))", background: isToday ? "hsla(var(--honey), 0.1)" : "hsl(var(--surface))", color: isToday ? "hsl(var(--honey))" : "hsl(var(--muted))", fontSize: 12, fontWeight: 600 }}>Aujourd'hui</button>
          <button onClick={() => navDay(1)} style={{ padding: "7px 10px", borderRadius: 6, border: "1.5px solid hsl(var(--border))", color: "hsl(var(--muted))", background: "hsl(var(--surface))" }}>→</button>
        </div>
      </div>
      <div className="rise s1" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "14px 20px", marginBottom: 18, display: "flex", alignItems: "center", gap: 14, boxShadow: "var(--sh-xs)" }}>
        <Ring value={filled} max={JOURNAL_QUESTIONS.length} size={52} stroke={4.5} color={filled === JOURNAL_QUESTIONS.length ? "hsl(var(--green))" : "hsl(var(--honey))"} label={`${filled}`} />
        <div><p style={{ fontWeight: 600, color: "hsl(var(--bark))", fontSize: 15, textTransform: "capitalize" }}>{new Date(date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</p><p style={{ fontSize: 12, color: "hsl(var(--muted))", marginTop: 2 }}>{filled}/{JOURNAL_QUESTIONS.length} réponses · {saving ? "Sauvegarde…" : filled > 0 ? "Sauvegardé ✓" : "Commence à écrire"}</p></div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {JOURNAL_QUESTIONS.map((q, i) => (
          <div key={i} className="rise" style={{ animationDelay: `${i * 0.07}s`, background: "hsl(var(--surface))", border: "1.5px solid", borderColor: entries[i]?.trim() ? "hsla(var(--olive), 0.22)" : "hsl(var(--border))", borderRadius: 10, padding: "16px 18px", boxShadow: "var(--sh-xs)", transition: "border-color .3s" }}>
            <p style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic", fontSize: 16, color: "hsl(var(--bark))", marginBottom: 10, lineHeight: 1.5 }}>{i + 1}. {q}</p>
            <textarea value={entries[i] || ""} onChange={e => update(i, e.target.value)} placeholder="Écris ce qui te vient naturellement…" rows={3} style={{ fontSize: 13.5, padding: "10px 12px", lineHeight: 1.85 }} />
          </div>
        ))}
      </div>
    </div>
  );
};

// ═══ HABITUDES (merged with routines) ═══
export const Habitudes = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [habitudes, setHabitudes] = useState<any[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ nom: "", emoji: "💪", color: HAB_COLORS[0] });

  useEffect(() => { db.get("habitudes").then(h => setHabitudes(h || [])); }, []);
  const save = async (u: any[]) => { setHabitudes(u); await db.set("habitudes", u); };

  const addHab = async () => { if (!form.nom.trim()) return; const h = { id: Date.now(), nom: form.nom.trim(), emoji: form.emoji, color: form.color, jours: Array(7).fill(false), streak: 0 }; await save([...habitudes, h]); setModal(false); setForm({ nom: "", emoji: "💪", color: HAB_COLORS[0] }); showToast("Habitude créée ✓"); addXP(15, "Nouvelle habitude", "new-hab"); };
  const delHab = async (id: number) => { const ok = await ask("Supprimer cette habitude ?"); if (!ok) return; await save(habitudes.filter(h => h.id !== id)); showToast("Supprimée", "warn"); };

  const toggle = async (id: number, di: number) => {
    const u = habitudes.map(h => {
      if (h.id !== id) return h;
      const jours = [...(h.jours || Array(7).fill(false))];
      jours[di] = !jours[di];
      const streak = jours[di] ? (h.streak || 0) + 1 : Math.max(0, (h.streak || 0) - 1);
      return { ...h, jours, streak };
    });
    await save(u);
    const habit = u.find(h => h.id === id);
    if (habit?.jours[di]) addXP(10, "Habitude ✓", `hab-${id}-${di}`);
  };

  const todayIdx = (new Date().getDay() + 6) % 7;
  const totalDone = habitudes.reduce((a: number, h: any) => a + (h.jours || []).filter(Boolean).length, 0);
  const totalPossible = habitudes.length * (todayIdx + 1);

  return (
    <div className="scale-in">
      {ConfirmDialog}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 22 }}>
        <div className="rise"><h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Habitudes</h2><p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>{habitudes.length} habitude{habitudes.length !== 1 ? "s" : ""} · {totalPossible ? Math.round(totalDone / totalPossible * 100) : 0}% cette semaine</p></div>
        <Btn onClick={() => setModal(true)}><Ic d={IC.plus} size={15} /> Nouvelle</Btn>
      </div>
      {habitudes.length === 0 && <div style={{ textAlign: "center", padding: "72px 0", color: "hsl(var(--muted2))" }}><div className="float" style={{ fontSize: 52, marginBottom: 14 }}>🔁</div><p style={{ fontSize: 15, fontStyle: "italic" }}>Crée ta première habitude.</p></div>}
      {/* Day headers */}
      {habitudes.length > 0 && <div style={{ display: "grid", gridTemplateColumns: "1fr repeat(7, 34px)", gap: 5, marginBottom: 8, paddingRight: 0 }}>
        <div />
        {["Lu", "Ma", "Me", "Je", "Ve", "Sa", "Di"].map((j, i) => <div key={i} style={{ textAlign: "center", fontSize: 10, fontWeight: 600, color: i === todayIdx ? "hsl(var(--honey))" : "hsl(var(--muted))" }}>{j}</div>)}
      </div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {habitudes.map((h: any, hi: number) => {
          const done = (h.jours || []).filter(Boolean).length;
          const pct = Math.round(done / 7 * 100);
          return (
            <div key={h.id} className="rise" style={{ animationDelay: `${hi * 0.05}s`, background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "12px 14px", boxShadow: "var(--sh-xs)" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr repeat(7, 34px)", gap: 5, alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
                  <span style={{ fontSize: 19, flexShrink: 0 }}>{h.emoji}</span>
                  <div style={{ minWidth: 0 }}>
                    <p style={{ fontWeight: 600, fontSize: 13, color: "hsl(var(--bark))", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{h.nom}</p>
                    <div style={{ display: "flex", alignItems: "center", gap: 5, marginTop: 2 }}>
                      <div style={{ height: 3, width: 44, background: "hsl(var(--surface2))", borderRadius: 2, overflow: "hidden" }}><div style={{ height: "100%", width: `${pct}%`, background: h.color || "hsl(var(--olive))", borderRadius: 2, transition: "width .5s" }} /></div>
                      {(h.streak || 0) > 0 && <span style={{ fontSize: 10, color: "hsl(var(--honey))", fontWeight: 600 }} className={(h.streak || 0) >= 3 ? "flame-anim" : ""}>🔥{h.streak}</span>}
                    </div>
                  </div>
                </div>
                {(h.jours || Array(7).fill(false)).map((checked: boolean, di: number) => {
                  const isFuture = di > todayIdx, isToday = di === todayIdx;
                  return <button key={di} onClick={() => toggle(h.id, di)} disabled={isFuture} style={{ width: 32, height: 32, borderRadius: 6, border: "1.5px solid", borderColor: checked ? h.color || "hsl(var(--olive))" : "hsl(var(--border))", background: checked ? h.color || "hsl(var(--olive))" : isFuture ? "hsl(var(--surface2))" : "hsl(var(--surface))", color: checked ? "hsl(var(--background))" : "hsl(var(--muted2))", fontSize: 12, display: "flex", alignItems: "center", justifyContent: "center", transition: "all .18s", opacity: isFuture ? 0.35 : 1, outline: isToday ? "2px solid hsl(var(--honey))" : "none", outlineOffset: "2px", cursor: isFuture ? "not-allowed" : "pointer" }}>{checked ? "✓" : ""}</button>;
                })}
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 6 }}>
                <button onClick={() => delHab(h.id)} style={{ fontSize: 11, color: "hsl(var(--muted2))", padding: "2px 8px", borderRadius: 4 }}>Supprimer</button>
              </div>
            </div>
          );
        })}
      </div>
      {modal && <Modal title="Nouvelle habitude" onClose={() => setModal(false)}>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>{HAB_EMOJIS.map(em => <button key={em} onClick={() => setForm(f => ({ ...f, emoji: em }))} style={{ fontSize: 19, padding: "6px 8px", borderRadius: 6, background: form.emoji === em ? "hsl(var(--surface2))" : "transparent", border: form.emoji === em ? "1.5px solid hsl(var(--honey))" : "1.5px solid transparent", transform: form.emoji === em ? "scale(1.15)" : "scale(1)", transition: "all .15s" }}>{em}</button>)}</div>
        <Field label="Nom de l'habitude"><input autoFocus placeholder="Ex: Boire 2L d'eau…" value={form.nom} onChange={e => setForm(f => ({ ...f, nom: e.target.value }))} onKeyDown={e => e.key === "Enter" && addHab()} /></Field>
        <Field label="Couleur"><div style={{ display: "flex", gap: 8 }}>{HAB_COLORS.map(c => <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))} style={{ width: 28, height: 28, borderRadius: "50%", background: c, border: form.color === c ? "3px solid hsl(var(--bark))" : "3px solid transparent", transform: form.color === c ? "scale(1.2)" : "scale(1)", transition: "transform .15s" }} />)}</div></Field>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
          <Btn v="ghost" onClick={() => setModal(false)}>Annuler</Btn>
          <Btn onClick={addHab} disabled={!form.nom.trim()}>Créer</Btn>
        </div>
      </Modal>}
    </div>
  );
};

// ═══ SUIVI — Objectifs ═══
export const Suivi = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [objectifs, setObjectifs] = useState<any[]>([]);
  const [open, setOpen] = useState<any>(null);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ nom: "", desc: "", cible: "", unite: "", nbJours: "7" });
  const [saving, setSaving] = useState(false);
  const timer = useRef<any>(null);

  useEffect(() => { db.get("objectifs").then(o => setObjectifs(o || [])); }, []);
  const save = async (u: any[]) => { setObjectifs(u); await db.set("objectifs", u); };

  const addObjectif = async () => {
    if (!form.nom.trim()) return;
    const obj = { id: Date.now(), nom: form.nom.trim(), desc: form.desc.trim(), cible: form.cible.trim(), unite: form.unite.trim(), jours: JOURS.slice(0, parseInt(form.nbJours) || 7).map(j => ({ jour: j, cases: [] as any[], note: "" })), createdAt: new Date().toLocaleDateString("fr-FR") };
    await save([...objectifs, obj]); setModal(false); setForm({ nom: "", desc: "", cible: "", unite: "", nbJours: "7" }); showToast("Objectif créé ✓"); addXP(20, "Nouvel objectif", "new-obj");
  };

  const delObjectif = async (id: number) => { const ok = await ask("Supprimer cet objectif ?"); if (!ok) return; await save(objectifs.filter(o => o.id !== id)); if (open?.id === id) setOpen(null); showToast("Objectif supprimé", "warn"); };

  const toggleCase = async (objId: number, ji: number, ci: number) => {
    const u = objectifs.map(o => o.id !== objId ? o : { ...o, jours: o.jours.map((j: any, jj: number) => jj !== ji ? j : { ...j, cases: j.cases.map((c: any, cc: number) => cc !== ci ? c : { ...c, checked: !c.checked }) }) });
    await save(u);
    if (open?.id === objId) { const upd = u.find(o => o.id === objId); if (upd?.jours[ji]?.cases[ci]?.checked) addXP(5, "Tâche ✓", `case-${objId}-${ji}-${ci}`); setOpen(upd); }
  };

  const addCaseToJour = async (objId: number, ji: number, texte: string) => { if (!texte.trim()) return; const u = objectifs.map(o => o.id !== objId ? o : { ...o, jours: o.jours.map((j: any, jj: number) => jj !== ji ? j : { ...j, cases: [...j.cases, { id: Date.now(), texte: texte.trim(), checked: false }] }) }); await save(u); if (open?.id === objId) setOpen(u.find(o => o.id === objId)); };
  const delCase = async (objId: number, ji: number, ci: number) => { const u = objectifs.map(o => o.id !== objId ? o : { ...o, jours: o.jours.map((j: any, jj: number) => jj !== ji ? j : { ...j, cases: j.cases.filter((_: any, cc: number) => cc !== ci) }) }); await save(u); if (open?.id === objId) setOpen(u.find(o => o.id === objId)); };
  const updateNote = async (objId: number, ji: number, note: string) => { setSaving(true); clearTimeout(timer.current); timer.current = setTimeout(async () => { const u = objectifs.map(o => o.id !== objId ? o : { ...o, jours: o.jours.map((j: any, jj: number) => jj === ji ? { ...j, note } : j) }); await save(u); if (open?.id === objId) setOpen(u.find(o => o.id === objId)); setSaving(false); }, 600); };
  const getStats = (obj: any) => { const total = obj.jours.reduce((a: number, j: any) => a + j.cases.length, 0); const done = obj.jours.reduce((a: number, j: any) => a + j.cases.filter((c: any) => c.checked).length, 0); return { total, done, pct: total ? Math.round(done / total * 100) : 0 }; };

  if (open) {
    const obj = open, stats = getStats(obj);
    return (
      <div className="appear">
        {ConfirmDialog}
        <div style={{ display: "flex", alignItems: "center", gap: 11, paddingBottom: 14, borderBottom: "1.5px solid hsl(var(--border))", marginBottom: 20 }}>
          <button onClick={() => setOpen(null)} style={{ color: "hsl(var(--muted))", padding: 4 }}><Ic d={IC.back} /></button>
          <div style={{ flex: 1 }}><h2 className="cg-i" style={{ fontSize: 22, color: "hsl(var(--bark))", fontWeight: 500 }}>{obj.nom}</h2>{obj.desc && <p style={{ fontSize: 13, color: "hsl(var(--muted))", marginTop: 1 }}>{obj.desc}</p>}</div>
          <Ring value={stats.done} max={stats.total || 1} size={54} stroke={4.5} color={stats.pct === 100 ? "hsl(var(--green))" : "hsl(var(--olive))"} label={`${stats.pct}%`} />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
          {obj.jours.map((jour: any, ji: number) => {
            const dJ = jour.cases.filter((c: any) => c.checked).length, tJ = jour.cases.length;
            const done = obj.cible && dJ >= parseInt(obj.cible);
            return <JourCard key={ji} jour={jour} ji={ji} objId={obj.id} dJ={dJ} tJ={tJ} cible={obj.cible} unite={obj.unite} done={done} onToggle={ci => toggleCase(obj.id, ji, ci)} onAdd={t => addCaseToJour(obj.id, ji, t)} onDel={ci => delCase(obj.id, ji, ci)} onNote={n => updateNote(obj.id, ji, n)} />;
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="scale-in">
      {ConfirmDialog}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 22 }}>
        <div className="rise"><h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Suivi</h2><p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>Objectifs hebdomadaires</p></div>
        <Btn onClick={() => setModal(true)}><Ic d={IC.plus} size={15} /> Nouvel objectif</Btn>
      </div>
      {objectifs.length === 0 && <div style={{ textAlign: "center", padding: "72px 0", color: "hsl(var(--muted2))" }}><div className="float" style={{ fontSize: 52, marginBottom: 14 }}>🎯</div><p style={{ fontSize: 15, fontStyle: "italic" }}>Aucun objectif encore.</p></div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {objectifs.map((obj, i) => { const s = getStats(obj); return (
          <div key={obj.id} className="rise" style={{ animationDelay: `${i * 0.05}s` }}>
            <div style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "14px 18px", position: "relative", boxShadow: "var(--sh-xs)", cursor: "pointer" }} onClick={() => setOpen(obj)}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                <Ring value={s.done} max={s.total || 1} size={54} stroke={4.5} color={s.pct === 100 ? "hsl(var(--green))" : s.pct > 0 ? "hsl(var(--honey))" : "hsl(var(--surface3))"} label={`${s.pct}%`} />
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: 15, fontWeight: 600, color: "hsl(var(--bark))", marginBottom: 3 }}>{obj.nom}</h3>
                  {obj.desc && <p style={{ fontSize: 12, color: "hsl(var(--muted))", marginBottom: 5 }}>{obj.desc}</p>}
                  <div style={{ display: "flex", gap: 4, marginTop: 2 }}>{obj.jours.map((j: any, ji: number) => { const d = j.cases.filter((c: any) => c.checked).length, t = j.cases.length, p = t ? d / t : 0; return <div key={ji} style={{ width: 20, height: 5, borderRadius: 2, background: t === 0 ? "hsl(var(--surface2))" : p >= 1 ? "hsl(var(--green))" : p > 0 ? "hsl(var(--honey))" : "hsl(var(--surface3))" }} />; })}<span style={{ fontSize: 10, color: "hsl(var(--muted))", marginLeft: 3 }}>{s.done}/{s.total}</span></div>
                </div>
              </div>
              <button onClick={e => { e.stopPropagation(); delObjectif(obj.id); }} style={{ position: "absolute", top: 11, right: 11, background: "hsl(var(--surface2))", border: "1px solid hsl(var(--border))", borderRadius: 5, padding: "3px 5px", color: "hsl(var(--muted))", display: "flex" }}><Ic d={IC.trash} size={12} /></button>
            </div>
          </div>
        ); })}
      </div>
      {modal && <Modal title="Nouvel objectif" onClose={() => setModal(false)}>
        <Field label="Nom"><input autoFocus placeholder="Ex: Inviter des personnes" value={form.nom} onChange={e => setForm(f => ({ ...f, nom: e.target.value }))} /></Field>
        <Field label="Description (opt.)"><input placeholder="Ex: 25 personnes par jour" value={form.desc} onChange={e => setForm(f => ({ ...f, desc: e.target.value }))} /></Field>
        <div style={{ display: "flex", gap: 10 }}><Field label="Cible / jour" mb={14}><input placeholder="25" value={form.cible} onChange={e => setForm(f => ({ ...f, cible: e.target.value }))} /></Field><Field label="Unité" mb={14}><input placeholder="personnes…" value={form.unite} onChange={e => setForm(f => ({ ...f, unite: e.target.value }))} /></Field></div>
        <Field label="Jours"><select value={form.nbJours} onChange={e => setForm(f => ({ ...f, nbJours: e.target.value }))}>{[1, 2, 3, 4, 5, 6, 7].map(n => <option key={n} value={n}>{n} jour{n > 1 ? "s" : ""}</option>)}</select></Field>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}><Btn v="ghost" onClick={() => setModal(false)}>Annuler</Btn><Btn onClick={addObjectif} disabled={!form.nom.trim()}>Créer</Btn></div>
      </Modal>}
    </div>
  );
};

// ═══ JOUR CARD (for Suivi) ═══
const JourCard = ({ jour, ji, objId, dJ, tJ, cible, unite, done, onToggle, onAdd, onDel, onNote }: any) => {
  const [newCase, setNewCase] = useState("");
  const [noteVal, setNoteVal] = useState(jour.note || "");
  const [expanded, setExpanded] = useState(true);
  const handleAdd = () => { if (!newCase.trim()) return; onAdd(newCase.trim()); setNewCase(""); };
  const pct = tJ ? Math.round(dJ / tJ * 100) : 0;
  return (
    <div style={{ background: "hsl(var(--surface))", borderRadius: 10, overflow: "hidden", border: "1.5px solid", borderColor: done ? "hsl(var(--green))" : "hsl(var(--border))", borderLeftWidth: done ? 4 : 1.5, boxShadow: done ? "var(--sh-o)" : "var(--sh-xs)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "12px 16px", cursor: "pointer" }} onClick={() => setExpanded(e => !e)}>
        <div style={{ width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: done ? "hsl(var(--green))" : dJ > 0 ? "hsla(var(--olive), 0.1)" : "hsl(var(--surface2))", color: done ? "hsl(var(--background))" : dJ > 0 ? "hsl(var(--olive))" : "hsl(var(--muted2))", fontSize: 12, fontWeight: 700, flexShrink: 0 }}>{done ? "✓" : dJ}</div>
        <div style={{ flex: 1 }}><p style={{ fontWeight: 600, fontSize: 14, color: done ? "hsl(var(--green))" : "hsl(var(--bark))" }}>{jour.jour}</p><p style={{ fontSize: 11, color: "hsl(var(--muted))" }}>{dJ}/{tJ}{cible && ` — cible : ${cible} ${unite}`}</p></div>
        <span style={{ fontSize: 10, color: "hsl(var(--muted2))" }}>{expanded ? "▲" : "▼"}</span>
      </div>
      {expanded && <div style={{ padding: "0 16px 14px", borderTop: "1px solid hsl(var(--border))" }}>
        {jour.cases.length > 0 && <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 7 }}>
          {jour.cases.map((c: any, ci: number) => (
            <div key={c.id || ci} style={{ display: "flex", alignItems: "center", gap: 9, padding: "4px 0" }}>
              <div
                onClick={() => onToggle(ci)}
                style={{
                  width: 18, height: 18, borderRadius: 4, border: "1.5px solid",
                  borderColor: c.checked ? "hsl(var(--olive))" : "hsl(var(--border))",
                  background: c.checked ? "hsl(var(--olive))" : "transparent",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  cursor: "pointer", flexShrink: 0, transition: "all .2s",
                }}>
                {c.checked && <span className="check-pop" style={{ fontSize: 11, color: "hsl(var(--background))", fontWeight: 700, lineHeight: 1 }}>✓</span>}
              </div>
              <span style={{ flex: 1, fontSize: 13, position: "relative", lineHeight: 1.5, transition: "color 0.3s, opacity 0.3s", color: c.checked ? "hsl(var(--muted2))" : "hsl(var(--foreground))", opacity: c.checked ? 0.55 : 1 }}>
                {c.texte}
                {c.checked && (
                  <span style={{ position: "absolute", left: 0, top: "50%", height: "1.5px", background: "hsl(var(--muted))", borderRadius: 2, animation: "strike 0.35s cubic-bezier(0.22,1,0.36,1) forwards", width: "100%", display: "block", marginTop: "-0.75px" }} />
                )}
              </span>
              <button onClick={() => onDel(ci)} style={{ color: "hsl(var(--muted2))", padding: 3, opacity: 0.5, transition: "opacity .15s" }} onMouseEnter={e => (e.currentTarget as HTMLElement).style.opacity = "1"} onMouseLeave={e => (e.currentTarget as HTMLElement).style.opacity = "0.5"}><Ic d={IC.close} size={12} /></button>
            </div>
          ))}
        </div>}
        <div style={{ display: "flex", gap: 7, marginTop: 10 }}>
          <input placeholder={`Ajouter pour ${jour.jour}…`} value={newCase} onChange={e => setNewCase(e.target.value)} onKeyDown={e => e.key === "Enter" && handleAdd()} style={{ fontSize: 13 }} />
          <button onClick={handleAdd} style={{ background: "hsl(var(--olive))", color: "hsl(var(--background))", borderRadius: 6, padding: "0 13px", fontWeight: 700, fontSize: 15, flexShrink: 0 }}>+</button>
        </div>
        <div style={{ marginTop: 8 }}><textarea placeholder={`Note…`} value={noteVal} onChange={e => { setNoteVal(e.target.value); onNote(e.target.value); }} rows={2} style={{ fontSize: 12, padding: "7px 11px" }} /></div>
      </div>}
    </div>
  );
};

// ═══ BIBLIOTHÈQUE ═══
const BOOKS_PER_PAGE = 9;
const BOOK_COLORS = [
  "hsl(28, 55%, 28%)", "hsl(200, 45%, 28%)", "hsl(150, 35%, 25%)",
  "hsl(340, 45%, 32%)", "hsl(260, 30%, 32%)", "hsl(38, 65%, 30%)",
];

export const Library = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [books, setBooks] = useState<any[]>([]);
  const [open, setOpen] = useState<any>(null);
  const [content, setContent] = useState("");
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState("");
  const [emoji, setEmoji] = useState("📖");
  const [bookColor, setBookColor] = useState(BOOK_COLORS[0]);
  const [saving, setSaving] = useState(false);
  const [wc, setWc] = useState(0);
  const [page, setPage] = useState(0);
  const timer = useRef<any>(null);

  useEffect(() => { db.get("lib-books").then(b => setBooks(b || [])); }, []);

  const totalPages = Math.ceil(books.length / BOOKS_PER_PAGE);
  const visibleBooks = books.slice(page * BOOKS_PER_PAGE, (page + 1) * BOOKS_PER_PAGE);

  const openBook = async (book: any) => {
    const c = await db.get(`book-${book.id}`) || "";
    setContent(c as string);
    setWc(c && (c as string).trim() ? (c as string).trim().split(/\s+/).length : 0);
    setOpen(book);
  };

  const onType = (val: string) => {
    setContent(val);
    setWc(val.trim() ? val.trim().split(/\s+/).length : 0);
    setSaving(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      await db.set(`book-${open.id}`, val);
      setSaving(false);
      if (val.trim().split(/\s+/).length > 50) addXP(15, "Écriture ✓", "write-" + open.id);
    }, 700);
  };

  const addBook = async () => {
    if (!title.trim()) return;
    const book = {
      id: Date.now(), title: title.trim(), emoji,
      color: bookColor,
      created: new Date().toLocaleDateString("fr-FR"),
    };
    const u = [...books, book];
    setBooks(u);
    await db.set("lib-books", u);
    setModal(false); setTitle(""); setEmoji("📖"); setBookColor(BOOK_COLORS[0]);
    showToast("Livre créé ✓");
    addXP(20, "Nouveau livre", "new-book");
  };

  const delBook = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const ok = await ask("Supprimer ce livre ?");
    if (!ok) return;
    const u = books.filter(b => b.id !== id);
    setBooks(u);
    await db.set("lib-books", u);
    await db.del(`book-${id}`);
    if (open?.id === id) setOpen(null);
    if (page > 0 && visibleBooks.length === 1) setPage(p => p - 1);
    showToast("Livre supprimé", "warn");
  };

  // ── VUE LIVRE OUVERT ──
  if (open) return (
    <div className="page-enter" style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 72px)" }}>
      {ConfirmDialog}
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, paddingBottom: 16, borderBottom: "1.5px solid hsl(var(--border))", marginBottom: 24, flexShrink: 0 }}>
        <button onClick={() => setOpen(null)} style={{ color: "hsl(var(--muted))", padding: 6, borderRadius: 7, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--surface))", display: "flex", alignItems: "center", gap: 5, fontSize: 12, transition: "all .15s" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "hsl(var(--honey))"; (e.currentTarget as HTMLElement).style.color = "hsl(var(--honey))"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "hsl(var(--border))"; (e.currentTarget as HTMLElement).style.color = "hsl(var(--muted))"; }}>
          <Ic d={IC.back} size={14} /> Retour
        </button>
        <div style={{ width: 36, height: 36, borderRadius: 8, background: open.color || BOOK_COLORS[0], display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{open.emoji}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 className="cg-i" style={{ fontSize: 20, color: "hsl(var(--bark))", fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{open.title}</h2>
          <p style={{ fontSize: 11, color: "hsl(var(--muted2))", marginTop: 1 }}>Créé le {open.created}</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexShrink: 0 }}>
          <span style={{ fontSize: 12, color: "hsl(var(--muted2))" }}>{wc} mot{wc !== 1 ? "s" : ""}</span>
          <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 600, color: saving ? "hsl(var(--honey))" : "hsl(var(--green))" }}>
            {saving ? <><span style={{ fontSize: 10 }}>●</span> Sauvegarde…</> : <><span style={{ fontSize: 10 }}>●</span> Sauvegardé</>}
          </div>
        </div>
      </div>
      {/* Zone d'écriture — texte jamais coupé */}
      <div style={{ flex: 1, overflowY: "auto", paddingRight: 4 }}>
        <textarea
          value={content}
          onChange={e => onType(e.target.value)}
          placeholder="Commence à écrire ici… tes idées, tes réflexions, ton plan."
          autoFocus
          style={{
            width: "100%", minHeight: "100%", background: "transparent", border: "none",
            boxShadow: "none", fontSize: 16, lineHeight: 2, color: "hsl(var(--foreground))",
            padding: 0, resize: "none", fontFamily: "'DM Sans', sans-serif",
            overflowY: "hidden", whiteSpace: "pre-wrap", wordBreak: "break-word",
          }}
          onInput={e => {
            const el = e.currentTarget;
            el.style.height = "auto";
            el.style.height = el.scrollHeight + "px";
          }}
        />
      </div>
    </div>
  );

  // ── VUE GRILLE ──
  return (
    <div className="scale-in">
      {ConfirmDialog}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div className="rise">
          <h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Bibliothèque</h2>
          <p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>{books.length} livre{books.length !== 1 ? "s" : ""}{totalPages > 1 ? ` · page ${page + 1}/${totalPages}` : ""}</p>
        </div>
        <Btn onClick={() => setModal(true)}><Ic d={IC.plus} size={15} /> Nouveau</Btn>
      </div>

      {books.length === 0 && (
        <div style={{ textAlign: "center", padding: "80px 0", color: "hsl(var(--muted2))" }}>
          <div className="float" style={{ fontSize: 56, marginBottom: 16 }}>📚</div>
          <p className="cg-i" style={{ fontSize: 18, marginBottom: 6 }}>Ta bibliothèque t'attend.</p>
          <p style={{ fontSize: 13 }}>Crée ton premier livre pour commencer à écrire.</p>
        </div>
      )}

      {/* Grille livres — style vraie étagère */}
      <div className="book-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 14, marginBottom: 20 }}>
        {visibleBooks.map((book: any, i: number) => (
          <div key={book.id} className="rise" style={{ animationDelay: `${i * 0.05}s`, position: "relative" }}>
            {/* Livre — apparence d'un vrai livre */}
            <div className="book-card" onClick={() => openBook(book)} style={{
              cursor: "pointer", borderRadius: "4px 10px 10px 4px",
              boxShadow: "var(--sh-sm), -4px 0 0 0 rgba(0,0,0,0.15)",
              overflow: "hidden", userSelect: "none",
            }}>
              {/* Tranche colorée */}
              <div style={{ height: 6, background: book.color || BOOK_COLORS[0], width: "100%" }} />
              {/* Corps du livre */}
              <div style={{
                background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))",
                borderTop: "none", padding: "16px 14px 14px",
              }}>
                <div style={{ fontSize: 28, marginBottom: 10 }}>{book.emoji}</div>
                {/* Titre complet — jamais coupé */}
                <h3 style={{ fontSize: 13, fontWeight: 600, color: "hsl(var(--bark))", lineHeight: 1.5, wordBreak: "break-word", marginBottom: 8 }}>{book.title}</h3>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <p style={{ color: "hsl(var(--muted2))", fontSize: 10 }}>{book.created}</p>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: book.color || BOOK_COLORS[0], opacity: 0.7 }} />
                </div>
              </div>
            </div>
            <button onClick={e => delBook(book.id, e)} style={{ position: "absolute", top: 14, right: 8, background: "hsl(var(--surface2))", border: "1px solid hsl(var(--border))", borderRadius: 5, padding: "3px 5px", color: "hsl(var(--muted))", display: "flex", opacity: 0, transition: "opacity .15s" }}
              onMouseEnter={e => { const p = (e.currentTarget as HTMLElement).parentElement!; p.querySelector("button")!.style.opacity = "1"; }}
              className="delete-btn"
            ><Ic d={IC.trash} size={12} /></button>
          </div>
        ))}
      </div>

      {/* Navigation pages */}
      {totalPages > 1 && (
        <div className="rise" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
            style={{ padding: "8px 16px", borderRadius: 7, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--surface))", color: page === 0 ? "hsl(var(--muted2))" : "hsl(var(--muted))", fontSize: 13, opacity: page === 0 ? 0.4 : 1, transition: "all .15s" }}>
            ← Précédente
          </button>
          <div style={{ display: "flex", gap: 5 }}>
            {Array.from({ length: totalPages }, (_, i) => (
              <button key={i} onClick={() => setPage(i)} style={{ width: 28, height: 28, borderRadius: "50%", border: "1.5px solid", borderColor: i === page ? "hsl(var(--honey))" : "hsl(var(--border))", background: i === page ? "hsl(var(--honey))" : "hsl(var(--surface))", color: i === page ? "hsl(var(--background))" : "hsl(var(--muted))", fontSize: 12, fontWeight: i === page ? 700 : 400, transition: "all .18s" }}>{i + 1}</button>
            ))}
          </div>
          <button onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page === totalPages - 1}
            style={{ padding: "8px 16px", borderRadius: 7, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--surface))", color: page === totalPages - 1 ? "hsl(var(--muted2))" : "hsl(var(--muted))", fontSize: 13, opacity: page === totalPages - 1 ? 0.4 : 1, transition: "all .15s" }}>
            Suivante →
          </button>
        </div>
      )}

      {/* Hover delete fix */}
      <style>{`.book-card:hover ~ .delete-btn, .delete-btn:hover { opacity: 1 !important; }`}</style>

      {modal && (
        <Modal title="Nouveau livre" onClose={() => setModal(false)}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
            {EMOJIS.map(em => <button key={em} onClick={() => setEmoji(em)} style={{ fontSize: 19, padding: "6px 8px", borderRadius: 6, background: emoji === em ? "hsl(var(--surface2))" : "transparent", border: emoji === em ? "1.5px solid hsl(var(--honey))" : "1.5px solid transparent", transform: emoji === em ? "scale(1.15)" : "scale(1)", transition: "all .15s" }}>{em}</button>)}
          </div>
          <Field label="Couleur du livre">
            <div style={{ display: "flex", gap: 8 }}>
              {BOOK_COLORS.map(c => <button key={c} onClick={() => setBookColor(c)} style={{ width: 28, height: 28, borderRadius: 6, background: c, border: bookColor === c ? "3px solid hsl(var(--bark))" : "3px solid transparent", transform: bookColor === c ? "scale(1.2)" : "scale(1)", transition: "transform .15s" }} />)}
            </div>
          </Field>
          <Field label="Titre"><input autoFocus placeholder="Ex: Rêves, Ambitions, Stratégie…" value={title} onChange={e => setTitle(e.target.value)} onKeyDown={e => e.key === "Enter" && addBook()} /></Field>
          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
            <Btn v="ghost" onClick={() => setModal(false)}>Annuler</Btn>
            <Btn onClick={addBook} disabled={!title.trim()}>Créer</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ═══ CITATIONS ═══
export const CitationsPage = () => {
  const [search, setSearch] = useState("");
  const cit = citeDuJour();
  const filtered = CITATIONS.filter(c => c.text.toLowerCase().includes(search.toLowerCase()) || c.auteur.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="scale-in">
      <div style={{ marginBottom: 22 }} className="rise"><h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Citations</h2><p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>{CITATIONS.length} citations · une par jour</p></div>
      <div className="rise s1 grain" style={{ background: "linear-gradient(135deg, hsl(30, 60%, 4%), hsl(28, 45%, 6%))", borderRadius: 12, padding: "22px 26px", marginBottom: 18, position: "relative", overflow: "hidden" }}>
        <OrganicCanvas style={{ opacity: 0.45 }} />
        <p style={{ fontSize: 10, fontWeight: 600, color: "hsla(var(--honey), 0.6)", textTransform: "uppercase", letterSpacing: ".1em", marginBottom: 10 }}>Citation du jour</p>
        <p style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic", fontSize: 19, color: "#f0e8d8", lineHeight: 1.82, marginBottom: 10, fontWeight: 400 }}>"{cit.text}"</p>
        <p style={{ fontSize: 12, color: "rgba(200,150,50,.65)" }}>— {cit.auteur}</p>
      </div>
      <input placeholder="Rechercher…" value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 14 }} />
      <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
        {filtered.map((c, i) => (
          <div key={i} className="rise" style={{ animationDelay: `${Math.min(i, 12) * 0.025}s` }}>
            <div style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 8, padding: "12px 16px" }}>
              <p style={{ fontSize: 13.5, fontStyle: "italic", color: "hsl(var(--bark))", lineHeight: 1.8, marginBottom: 5 }}>"{c.text}"</p>
              <p style={{ fontSize: 11, color: "hsl(var(--honey))", fontWeight: 600 }}>— {c.auteur}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ══════════════════════════════════════════════════════
//  VIDÉOS À REGARDER — avec embed YouTube + catégories custom
// ══════════════════════════════════════════════════════
const DEFAULT_VIDEO_CATEGORIES = ["Business", "Marketing", "Tech", "Motivation", "Finance", "Autre"];

const CATEGORY_COLORS: Record<string, string> = {
  Business: "hsl(38,85%,50%)", Marketing: "hsl(200,70%,50%)", Tech: "hsl(260,60%,60%)",
  Motivation: "hsl(88,45%,45%)", Finance: "hsl(160,55%,42%)", Autre: "hsl(var(--muted))",
};

const getYoutubeId = (url: string) => {
  const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\s?]+)/);
  return m ? m[1] : null;
};

const VideoPlayer = ({ url, onClose }: { url: string; onClose: () => void }) => {
  const ytId = getYoutubeId(url);
  return (
    <div className="appear" onClick={e=>e.target===e.currentTarget&&onClose()} style={{ position:"fixed",inset:0,background:"rgba(0,0,0,.85)",backdropFilter:"blur(12px)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,padding:20 }}>
      <div className="rise" style={{ width:"100%",maxWidth:800,borderRadius:16,overflow:"hidden",boxShadow:"0 30px 80px rgba(0,0,0,.6)",position:"relative" }}>
        <button onClick={onClose} style={{ position:"absolute",top:12,right:12,zIndex:10,background:"rgba(0,0,0,.6)",border:"1px solid rgba(255,255,255,.15)",borderRadius:"50%",width:32,height:32,color:"#fff",fontSize:14,display:"flex",alignItems:"center",justifyContent:"center" }}>✕</button>
        {ytId ? (
          <iframe
            src={`https://www.youtube.com/embed/${ytId}?autoplay=1`}
            width="100%" height="450"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen style={{ display:"block",border:"none" }}
          />
        ) : (
          <div style={{ height:200,display:"flex",alignItems:"center",justifyContent:"center",background:"hsl(var(--surface))",gap:12 }}>
            <a href={url} target="_blank" rel="noopener noreferrer" style={{ color:"hsl(var(--honey))",fontSize:14,fontWeight:600 }}>Ouvrir le lien ↗</a>
          </div>
        )}
      </div>
    </div>
  );
};

export const Videos = () => {
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [videos, setVideos]   = useState<any[]>([]);
  const [categories, setCategories] = useState<string[]>(DEFAULT_VIDEO_CATEGORIES);
  const [modal, setModal]     = useState(false);
  const [catModal, setCatModal] = useState(false);
  const [playerUrl, setPlayerUrl] = useState<string|null>(null);
  const [filter, setFilter]   = useState("Tous");
  const [sortBy, setSortBy]   = useState<"date"|"categorie"|"titre">("date");
  const [search, setSearch]   = useState("");
  const [form, setForm]       = useState({ titre:"", lien:"", categorie:"", note:"" });
  const [watched, setWatched] = useState<Set<number>>(new Set());
  const [newCat, setNewCat]   = useState("");

  useEffect(() => {
    db.get("videos-later").then((v:any) => setVideos(v||[]));
    db.get("videos-watched").then((w:any) => setWatched(new Set(w||[])));
    db.get("video-categories").then((c:any) => { if (c) setCategories(c); });
  }, []);

  useEffect(() => { if (categories.length > 0 && !form.categorie) setForm(f => ({...f, categorie: categories[0]})); }, [categories]);

  const saveCategories = async (u: string[]) => { setCategories(u); await db.set("video-categories", u); };
  const save = async (u: any[]) => { setVideos(u); await db.set("videos-later", u); };

  const addCategory = async () => {
    if (!newCat.trim() || categories.includes(newCat.trim())) return;
    await saveCategories([...categories, newCat.trim()]);
    setNewCat("");
    showToast("Catégorie ajoutée ✓");
  };

  const delCategory = async (cat: string) => {
    const ok = await ask(`Supprimer la catégorie "${cat}" ?`);
    if (!ok) return;
    await saveCategories(categories.filter(c => c !== cat));
    if (filter === cat) setFilter("Tous");
    showToast("Catégorie supprimée", "warn");
  };

  const getCatColor = (cat: string) => CATEGORY_COLORS[cat] || `hsl(${(cat.charCodeAt(0) * 37) % 360},55%,50%)`;

  const addVideo = async () => {
    if (!form.titre.trim() || !form.lien.trim()) return;
    const video = { id:Date.now(), titre:form.titre.trim(), lien:form.lien.trim(), categorie:form.categorie||categories[0], note:form.note.trim(), date:new Date().toLocaleDateString("fr-FR") };
    await save([video,...videos]);
    setModal(false); setForm({titre:"",lien:"",categorie:categories[0]||"",note:""});
    showToast("Vidéo ajoutée ✓");
  };

  const delVideo = async (id: number) => {
    const ok = await ask("Supprimer cette vidéo ?");
    if (!ok) return;
    await save(videos.filter(v=>v.id!==id));
    showToast("Supprimée","warn");
  };

  const toggleWatched = async (id: number) => {
    const nw = new Set(watched);
    nw.has(id) ? nw.delete(id) : nw.add(id);
    setWatched(nw);
    await db.set("videos-watched", Array.from(nw));
    if (!watched.has(id)) showToast("Marquée comme vue ✓");
  };

  const filtered = videos
    .filter(v => filter==="Tous" || v.categorie===filter)
    .filter(v => !search || v.titre.toLowerCase().includes(search.toLowerCase()))
    .sort((a,b) => {
      if (sortBy==="titre") return a.titre.localeCompare(b.titre);
      if (sortBy==="categorie") return a.categorie.localeCompare(b.categorie);
      return b.id-a.id;
    });

  const total = videos.length;
  const vues  = videos.filter(v=>watched.has(v.id)).length;

  return (
    <div className="scale-in" style={{ paddingBottom:40 }}>
      {ConfirmDialog}
      {playerUrl && <VideoPlayer url={playerUrl} onClose={()=>setPlayerUrl(null)}/>}

      {/* HERO */}
      <div className="rise grain" style={{ position:"relative",overflow:"hidden",borderRadius:16,marginBottom:22,background:"linear-gradient(135deg,hsl(0,0%,4%),hsl(20,20%,6%))",border:"1.5px solid rgba(255,255,255,.06)",padding:"24px 26px" }}>
        <div style={{ position:"absolute",top:-30,right:-30,width:160,height:160,borderRadius:"50%",background:"radial-gradient(circle,rgba(212,48,48,.1),transparent 70%)",pointerEvents:"none" }}/>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",gap:16 }}>
          <div>
            <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:6 }}>
              <span className="float" style={{fontSize:28}}>🎬</span>
              <h2 className="cg-i" style={{fontSize:26,color:"#f0e4c4",fontWeight:500}}>À regarder</h2>
            </div>
            <div style={{ display:"flex",gap:16 }}>
              <div><p style={{fontSize:9,color:"rgba(240,228,196,.4)",textTransform:"uppercase",letterSpacing:".1em",fontWeight:600}}>Total</p><p className="mono" style={{fontSize:18,color:"rgba(240,228,196,.85)",fontWeight:700}}>{total}</p></div>
              <div><p style={{fontSize:9,color:"rgba(240,228,196,.4)",textTransform:"uppercase",letterSpacing:".1em",fontWeight:600}}>Vues</p><p className="mono" style={{fontSize:18,color:"hsl(160,55%,55%)",fontWeight:700}}>{vues}</p></div>
              <div><p style={{fontSize:9,color:"rgba(240,228,196,.4)",textTransform:"uppercase",letterSpacing:".1em",fontWeight:600}}>Restantes</p><p className="mono" style={{fontSize:18,color:"hsl(38,85%,55%)",fontWeight:700}}>{total-vues}</p></div>
            </div>
          </div>
          <div style={{ display:"flex", gap:7 }}>
            <button onClick={()=>setCatModal(true)} style={{ padding:"9px 14px",borderRadius:9,background:"rgba(255,255,255,.07)",border:"1.5px solid rgba(255,255,255,.1)",color:"rgba(240,228,196,.7)",fontSize:11,fontWeight:600,transition:"all .18s" }}
              onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="rgba(255,255,255,.12)";}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="rgba(255,255,255,.07)";}}>
              ⚙ Catégories
            </button>
            <button onClick={()=>setModal(true)} style={{ padding:"9px 16px",borderRadius:9,background:"rgba(212,160,48,.15)",border:"1.5px solid rgba(212,160,48,.3)",color:"hsl(38,85%,65%)",fontSize:12,fontWeight:700,display:"flex",alignItems:"center",gap:6,transition:"all .18s" }}
              onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="rgba(212,160,48,.25)";}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="rgba(212,160,48,.15)";}}>
              <Ic d={IC.plus} size={13}/> Ajouter
            </button>
          </div>
        </div>
      </div>

      {/* FILTRES */}
      <div className="rise s1" style={{ display:"flex",flexWrap:"wrap",gap:6,marginBottom:14,alignItems:"center" }}>
        <div style={{ display:"flex",gap:5,flexWrap:"wrap",flex:1 }}>
          {["Tous", ...categories].map(cat=>(
            <button key={cat} onClick={()=>setFilter(cat)} style={{ padding:"5px 12px",borderRadius:99,fontSize:11,fontWeight:filter===cat?700:400,background:filter===cat ? (cat==="Tous"?"hsl(var(--honey))":getCatColor(cat)) :"hsl(var(--surface))",color:filter===cat?"#fff":"hsl(var(--muted))",border:"1.5px solid",borderColor:filter===cat?(cat==="Tous"?"hsl(var(--honey))":getCatColor(cat)):"hsl(var(--border))",transition:"all .15s" }}>{cat}</button>
          ))}
        </div>
        <div style={{ display:"flex",gap:6,alignItems:"center" }}>
          <input placeholder="Rechercher…" value={search} onChange={e=>setSearch(e.target.value)} style={{ width:150,fontSize:12,padding:"6px 11px" }}/>
          <select value={sortBy} onChange={e=>setSortBy(e.target.value as any)} style={{ fontSize:12,padding:"6px 10px",width:"auto" }}>
            <option value="date">Récent</option>
            <option value="titre">A→Z</option>
            <option value="categorie">Catégorie</option>
          </select>
        </div>
      </div>

      {filtered.length===0 && (
        <div style={{ textAlign:"center",padding:"64px 0",color:"hsl(var(--muted2))" }}>
          <div className="float" style={{fontSize:52,marginBottom:14}}>🎬</div>
          <p className="cg-i" style={{fontSize:17,marginBottom:6}}>Aucune vidéo encore.</p>
        </div>
      )}

      <div style={{ display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(250px,1fr))",gap:14 }}>
        {filtered.map((v:any, i:number) => {
          const ytId      = getYoutubeId(v.lien);
          const thumb     = ytId ? `https://img.youtube.com/vi/${ytId}/mqdefault.jpg` : null;
          const isWatched = watched.has(v.id);
          const catColor  = getCatColor(v.categorie);
          return (
            <div key={v.id} className="rise" style={{ animationDelay:`${Math.min(i,8)*.05}s`,background:"hsl(var(--surface))",border:"1.5px solid hsl(var(--border))",borderRadius:14,overflow:"hidden",opacity:isWatched?.65:1,transition:"all .25s cubic-bezier(.22,1,.36,1)" }}
              onMouseEnter={e=>{if(!isWatched){(e.currentTarget as HTMLElement).style.transform="translateY(-4px)";(e.currentTarget as HTMLElement).style.boxShadow="var(--sh-md)";(e.currentTarget as HTMLElement).style.borderColor=catColor;}}}
              onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform="none";(e.currentTarget as HTMLElement).style.boxShadow="none";(e.currentTarget as HTMLElement).style.borderColor="hsl(var(--border))";}}>
              <div onClick={()=>setPlayerUrl(v.lien)} style={{ position:"relative",height:148,background:"hsl(var(--surface2))",cursor:"pointer",overflow:"hidden" }}>
                {thumb ? (
                  <img src={thumb} alt={v.titre} style={{ width:"100%",height:"100%",objectFit:"cover",filter:isWatched?"grayscale(60%)":"none",transition:"transform .3s,filter .3s" }}
                    onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.transform="scale(1.04)";}}
                    onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform="none";}}/>
                ) : (
                  <div style={{ width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",background:`linear-gradient(135deg,${catColor}33,hsl(var(--surface2)))` }}>
                    <Ic d={IC.video} size={36} color={catColor}/>
                  </div>
                )}
                {!isWatched && <div style={{ position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",opacity:0,transition:"opacity .2s",background:"rgba(0,0,0,.35)" }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.opacity="1";}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.opacity="0";}}>
                  <div style={{ width:48,height:48,borderRadius:"50%",background:"rgba(255,255,255,.9)",display:"flex",alignItems:"center",justifyContent:"center" }}><span style={{fontSize:18,marginLeft:3}}>▶</span></div>
                </div>}
                <div style={{ position:"absolute",top:8,left:8,background:catColor,color:"#fff",fontSize:9,fontWeight:700,padding:"3px 8px",borderRadius:99 }}>{v.categorie}</div>
                {isWatched && <div style={{ position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.35)" }}><div style={{ width:40,height:40,borderRadius:"50%",background:"hsl(160,55%,42%)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18 }}>✓</div></div>}
              </div>
              <div style={{ padding:"12px 14px 14px" }}>
                <h3 style={{ fontSize:13,fontWeight:600,color:"hsl(var(--bark))",lineHeight:1.5,marginBottom:5,wordBreak:"break-word",textDecoration:isWatched?"line-through":"none" }}>{v.titre}</h3>
                {v.note && <p style={{ fontSize:11,color:"hsl(var(--muted))",marginBottom:7,lineHeight:1.5,fontStyle:"italic" }}>{v.note}</p>}
                <p style={{ fontSize:10,color:"hsl(var(--muted2))",marginBottom:10 }}>{v.date}</p>
                <div style={{ display:"flex",gap:5 }}>
                  <button onClick={()=>setPlayerUrl(v.lien)} style={{ flex:1,padding:"7px 0",borderRadius:7,background:ytId?"hsl(0,75%,55%)":"hsl(var(--honey))",color:"#fff",fontSize:11,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center",gap:4,transition:"filter .15s" }}
                    onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.filter="brightness(.88)";}}
                    onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.filter="none";}}>
                    {ytId?"▶ Regarder":"↗ Ouvrir"}
                  </button>
                  <button onClick={()=>toggleWatched(v.id)} style={{ padding:"7px 9px",borderRadius:7,border:"1.5px solid",borderColor:isWatched?"hsl(160,55%,42%)":"hsl(var(--border))",background:isWatched?"hsla(160,55%,42%,.12)":"hsl(var(--surface2))",color:isWatched?"hsl(160,55%,42%)":"hsl(var(--muted))",fontSize:11,fontWeight:600,transition:"all .18s" }}>{isWatched?"✓":"◯"}</button>
                  <button onClick={()=>delVideo(v.id)} style={{ padding:"7px 9px",borderRadius:7,border:"1.5px solid hsl(var(--border))",background:"hsl(var(--surface2))",color:"hsl(var(--muted))",display:"flex",transition:"all .15s" }}
                    onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.background="hsl(var(--destructive))";(e.currentTarget as HTMLElement).style.color="#fff";}}
                    onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.background="hsl(var(--surface2))";(e.currentTarget as HTMLElement).style.color="hsl(var(--muted))";}}><Ic d={IC.trash} size={13}/></button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* MODAL CATÉGORIES */}
      {catModal && (
        <Modal title="Gérer les catégories" onClose={()=>setCatModal(false)}>
          <div style={{ display:"flex",flexDirection:"column",gap:8,marginBottom:16,maxHeight:260,overflowY:"auto" }}>
            {categories.map(cat=>(
              <div key={cat} style={{ display:"flex",alignItems:"center",gap:10,padding:"8px 12px",background:"hsl(var(--surface2))",borderRadius:8,border:"1.5px solid hsl(var(--border))" }}>
                <div style={{ width:10,height:10,borderRadius:"50%",background:getCatColor(cat),flexShrink:0 }}/>
                <span style={{ flex:1,fontSize:13,color:"hsl(var(--bark))",fontWeight:500 }}>{cat}</span>
                <span style={{ fontSize:10,color:"hsl(var(--muted2))" }}>{videos.filter(v=>v.categorie===cat).length} vidéo{videos.filter(v=>v.categorie===cat).length!==1?"s":""}</span>
                <button onClick={()=>delCategory(cat)} style={{ color:"hsl(var(--muted2))",padding:3,display:"flex",transition:"color .15s" }}
                  onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.color="hsl(var(--destructive))";}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.color="hsl(var(--muted2))";}}><Ic d={IC.trash} size={13}/></button>
              </div>
            ))}
          </div>
          <div style={{ display:"flex",gap:7 }}>
            <input autoFocus placeholder="Nouvelle catégorie…" value={newCat} onChange={e=>setNewCat(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addCategory()} style={{ flex:1,fontSize:13 }}/>
            <Btn onClick={addCategory} disabled={!newCat.trim()}>Ajouter</Btn>
          </div>
        </Modal>
      )}

      {/* MODAL AJOUT */}
      {modal && (
        <Modal title="Ajouter une vidéo" onClose={()=>setModal(false)}>
          <Field label="Titre"><input autoFocus placeholder="Ex: Comment créer une startup…" value={form.titre} onChange={e=>setForm(f=>({...f,titre:e.target.value}))}/></Field>
          <Field label="Lien YouTube ou autre">
            <input placeholder="https://youtube.com/watch?v=..." value={form.lien} onChange={e=>setForm(f=>({...f,lien:e.target.value}))}/>
            {form.lien && getYoutubeId(form.lien) && (
              <div style={{ marginTop:8,borderRadius:8,overflow:"hidden",height:120 }}>
                <img src={`https://img.youtube.com/vi/${getYoutubeId(form.lien)}/mqdefault.jpg`} style={{ width:"100%",height:"100%",objectFit:"cover" }} alt="preview"/>
              </div>
            )}
          </Field>
          <Field label="Catégorie">
            <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
              {categories.map(cat=>(
                <button key={cat} onClick={()=>setForm(f=>({...f,categorie:cat}))} style={{ padding:"5px 12px",borderRadius:99,fontSize:11,fontWeight:form.categorie===cat?700:400,background:form.categorie===cat?getCatColor(cat):"hsl(var(--surface2))",color:form.categorie===cat?"#fff":"hsl(var(--muted))",border:"1.5px solid",borderColor:form.categorie===cat?getCatColor(cat):"hsl(var(--border))",transition:"all .15s" }}>{cat}</button>
              ))}
            </div>
          </Field>
          <Field label="Note (optionnel)"><input placeholder="Pourquoi tu veux regarder ça…" value={form.note} onChange={e=>setForm(f=>({...f,note:e.target.value}))}/></Field>
          <div style={{ display:"flex",gap:10,justifyContent:"flex-end",marginTop:8 }}>
            <Btn v="ghost" onClick={()=>setModal(false)}>Annuler</Btn>
            <Btn onClick={addVideo} disabled={!form.titre.trim()||!form.lien.trim()}>Ajouter</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
};

// ══════════════════════════════════════════════════════
//  TASKS — Graphique circulaire par jour
// ══════════════════════════════════════════════════════
type Task = { id: number; texte: string; jour: number; done: boolean; couleur: string; priorite: "haute" | "normale" | "basse" };

const TASK_COLORS = [
  "hsl(38,85%,50%)", "hsl(88,45%,45%)", "hsl(200,70%,50%)",
  "hsl(340,60%,55%)", "hsl(260,55%,60%)", "hsl(160,55%,42%)", "hsl(20,75%,55%)",
];

const JOURS_TASKS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

const CircleChart = ({ tasks, selectedJour, onSelectJour }: { tasks: Task[]; selectedJour: number; onSelectJour: (j: number) => void }) => {
  const cx = 160, cy = 160, r = 110;
  const dayCount = 7;
  const angleStep = (2 * Math.PI) / dayCount;
  const startAngle = -Math.PI / 2;

  return (
    <svg width={320} height={320} style={{ overflow: "visible" }}>
      {/* Cercles de fond */}
      {[30, 60, 90, 110].map(rr => (
        <circle key={rr} cx={cx} cy={cy} r={rr} fill="none" stroke="hsl(var(--border))" strokeWidth={1} opacity={0.4} />
      ))}

      {/* Axes des jours */}
      {JOURS_TASKS.map((_, i) => {
        const angle = startAngle + i * angleStep;
        return (
          <line key={i} x1={cx} y1={cy}
            x2={cx + (r + 20) * Math.cos(angle)}
            y2={cy + (r + 20) * Math.sin(angle)}
            stroke="hsl(var(--border))" strokeWidth={1} opacity={0.3} />
        );
      })}

      {/* Points des jours */}
      {JOURS_TASKS.map((jour, i) => {
        const angle = startAngle + i * angleStep;
        const dayTasks = tasks.filter(t => t.jour === i);
        const doneTasks = dayTasks.filter(t => t.done);
        const pct = dayTasks.length > 0 ? doneTasks.length / dayTasks.length : 0;
        const isSelected = selectedJour === i;
        const isToday = i === (new Date().getDay() + 6) % 7;

        const dotR = 10 + dayTasks.length * 2.5;
        const clampedR = Math.min(Math.max(dotR, 14), 32);
        const px = cx + r * Math.cos(angle);
        const py = cy + r * Math.sin(angle);

        // Arc de progression
        const arcR = clampedR + 4;
        const arcStart = { x: px + arcR * Math.cos(-Math.PI / 2), y: py + arcR * Math.sin(-Math.PI / 2) };
        const arcEnd = { x: px + arcR * Math.cos(-Math.PI / 2 + 2 * Math.PI * pct), y: py + arcR * Math.sin(-Math.PI / 2 + 2 * Math.PI * pct) };
        const largeArc = pct > 0.5 ? 1 : 0;

        return (
          <g key={i} onClick={() => onSelectJour(i)} style={{ cursor: "pointer" }}>
            {/* Arc de progression */}
            {pct > 0 && pct < 1 && (
              <path d={`M ${arcStart.x} ${arcStart.y} A ${arcR} ${arcR} 0 ${largeArc} 1 ${arcEnd.x} ${arcEnd.y}`}
                fill="none" stroke={TASK_COLORS[i % TASK_COLORS.length]} strokeWidth={3} strokeLinecap="round"
                style={{ transition: "all .8s cubic-bezier(.22,1,.36,1)" }} />
            )}
            {pct === 1 && (
              <circle cx={px} cy={py} r={arcR} fill="none" stroke={TASK_COLORS[i % TASK_COLORS.length]} strokeWidth={3} />
            )}
            {/* Cercle principal */}
            <circle cx={px} cy={py} r={clampedR}
              fill={isSelected ? TASK_COLORS[i % TASK_COLORS.length] : "hsl(var(--surface))"}
              stroke={isToday ? "hsl(var(--honey))" : isSelected ? TASK_COLORS[i % TASK_COLORS.length] : "hsl(var(--border))"}
              strokeWidth={isToday || isSelected ? 2.5 : 1.5}
              style={{ transition: "all .3s cubic-bezier(.22,1,.36,1)", filter: isSelected ? `drop-shadow(0 0 8px ${TASK_COLORS[i % TASK_COLORS.length]})` : "none" }} />
            {/* Nombre de tâches */}
            <text x={px} y={py + 1} textAnchor="middle" dominantBaseline="middle"
              fill={isSelected ? "white" : "hsl(var(--bark))"} fontSize={11} fontWeight={700} fontFamily="'DM Sans',sans-serif">
              {dayTasks.length}
            </text>
            {/* Label jour */}
            <text x={cx + (r + 36) * Math.cos(angle)} y={cy + (r + 36) * Math.sin(angle)}
              textAnchor="middle" dominantBaseline="middle"
              fill={isToday ? "hsl(var(--honey))" : isSelected ? TASK_COLORS[i % TASK_COLORS.length] : "hsl(var(--muted))"}
              fontSize={11} fontWeight={isToday || isSelected ? 700 : 500} fontFamily="'DM Sans',sans-serif">
              {jour}
            </text>
          </g>
        );
      })}

      {/* Centre stats */}
      <text x={cx} y={cy - 12} textAnchor="middle" fill="hsl(var(--bark))" fontSize={22} fontWeight={700} fontFamily="'DM Mono',monospace">
        {tasks.filter(t => t.done).length}/{tasks.length}
      </text>
      <text x={cx} y={cy + 10} textAnchor="middle" fill="hsl(var(--muted))" fontSize={10} fontWeight={600} fontFamily="'DM Sans',sans-serif" textTransform="uppercase" letterSpacing=".08em">
        complétées
      </text>
    </svg>
  );
};

export const Tasks = () => {
  const { addXP } = useXP();
  const { showToast } = useToast();
  const [ask, ConfirmDialog] = useConfirm();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedJour, setSelectedJour] = useState((new Date().getDay() + 6) % 7);
  const [newTask, setNewTask] = useState("");
  const [priorite, setPriorite] = useState<"haute" | "normale" | "basse">("normale");
  const [view, setView] = useState<"graph" | "list">("graph");

  useEffect(() => { db.get("tasks-v2").then((t: any) => setTasks(t || [])); }, []);

  const saveTasks = async (u: Task[]) => { setTasks(u); await db.set("tasks-v2", u); };

  const addTask = async () => {
    if (!newTask.trim()) return;
    const t: Task = { id: Date.now(), texte: newTask.trim(), jour: selectedJour, done: false, couleur: TASK_COLORS[selectedJour % TASK_COLORS.length], priorite };
    await saveTasks([...tasks, t]);
    setNewTask("");
    addXP(5, "Tâche ajoutée ✓", `task-add-${Date.now()}`);
    showToast("Tâche ajoutée ✓");
  };

  const toggleTask = async (id: number) => {
    const u = tasks.map(t => t.id === id ? { ...t, done: !t.done } : t);
    await saveTasks(u);
    const task = u.find(t => t.id === id);
    if (task?.done) addXP(10, "Tâche accomplie ✓", `task-done-${id}`);
  };

  const delTask = async (id: number) => {
    const ok = await ask("Supprimer cette tâche ?");
    if (!ok) return;
    await saveTasks(tasks.filter(t => t.id !== id));
    showToast("Supprimée", "warn");
  };

  const jourTasks = tasks.filter(t => t.jour === selectedJour);
  const donePct = tasks.length > 0 ? Math.round((tasks.filter(t => t.done).length / tasks.length) * 100) : 0;
  const PRIO_COLORS = { haute: "hsl(0,75%,55%)", normale: "hsl(var(--honey))", basse: "hsl(var(--muted))" };
  const PRIO_LABELS = { haute: "🔴 Haute", normale: "🟡 Normale", basse: "⚪ Basse" };

  return (
    <div className="scale-in" style={{ paddingBottom: 40 }}>
      {ConfirmDialog}

      {/* HEADER */}
      <div className="rise" style={{ marginBottom: 22 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, marginBottom: 16 }}>
          <div>
            <h2 className="cg-i" style={{ fontSize: 32, color: "hsl(var(--bark))", fontWeight: 500 }}>Tasks</h2>
            <p style={{ color: "hsl(var(--muted))", fontSize: 13, marginTop: 3 }}>
              {tasks.length} tâche{tasks.length !== 1 ? "s" : ""} · {donePct}% accompli{donePct > 0 ? "es" : ""}
            </p>
          </div>
          {/* Toggle vue */}
          <div style={{ display: "flex", gap: 3, background: "hsl(var(--surface))", padding: 3, borderRadius: 9, border: "1.5px solid hsl(var(--border))" }}>
            {([["graph", "⬤"], ["list", "☰"]] as const).map(([v, icon]) => (
              <button key={v} onClick={() => setView(v)} style={{ padding: "6px 14px", borderRadius: 7, fontSize: 14, background: view === v ? "hsl(var(--honey))" : "transparent", color: view === v ? "hsl(var(--background))" : "hsl(var(--muted))", transition: "all .18s", fontWeight: view === v ? 700 : 400 }}>{icon}</button>
            ))}
          </div>
        </div>
      </div>

      {/* VUE GRAPHIQUE */}
      {view === "graph" && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 22 }}>

          {/* Graphique circulaire */}
          <div className="rise s1" style={{ display: "flex", justifyContent: "center", background: "hsl(var(--surface))", borderRadius: 20, padding: "28px 20px", border: "1.5px solid hsl(var(--border))", width: "100%", boxShadow: "var(--sh-md)" }}>
            <CircleChart tasks={tasks} selectedJour={selectedJour} onSelectJour={setSelectedJour} />
          </div>

          {/* Jour sélectionné — tâches */}
          <div className="rise s2" style={{ width: "100%", background: "hsl(var(--surface))", borderRadius: 16, border: "1.5px solid", borderColor: TASK_COLORS[selectedJour % TASK_COLORS.length] + "55", overflow: "hidden" }}>
            {/* Header jour */}
            <div style={{ background: `linear-gradient(135deg, ${TASK_COLORS[selectedJour % TASK_COLORS.length]}22, transparent)`, padding: "16px 20px", borderBottom: "1px solid hsl(var(--border))", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <p style={{ fontWeight: 700, fontSize: 16, color: "hsl(var(--bark))" }}>{JOURS_TASKS[selectedJour]}</p>
                <p style={{ fontSize: 11, color: "hsl(var(--muted))", marginTop: 2 }}>{jourTasks.filter(t => t.done).length}/{jourTasks.length} tâches</p>
              </div>
              {jourTasks.length > 0 && (
                <div style={{ height: 5, width: 80, background: "hsl(var(--surface2))", borderRadius: 99, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: `${jourTasks.length > 0 ? (jourTasks.filter(t => t.done).length / jourTasks.length) * 100 : 0}%`, background: TASK_COLORS[selectedJour % TASK_COLORS.length], borderRadius: 99, transition: "width .8s cubic-bezier(.22,1,.36,1)" }} />
                </div>
              )}
            </div>

            {/* Liste tâches du jour */}
            <div style={{ padding: "14px 20px", display: "flex", flexDirection: "column", gap: 8 }}>
              {jourTasks.length === 0 && (
                <p style={{ textAlign: "center", color: "hsl(var(--muted2))", fontSize: 13, padding: "20px 0", fontStyle: "italic" }}>Aucune tâche pour ce jour.</p>
              )}
              {jourTasks.map((t, i) => (
                <div key={t.id} className="rise" style={{ animationDelay: `${i * 0.05}s`, display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", background: t.done ? "hsl(var(--surface2))" : "hsl(var(--background))", borderRadius: 10, border: "1.5px solid", borderColor: t.done ? "transparent" : PRIO_COLORS[t.priorite] + "44", transition: "all .25s" }}>
                  {/* Checkbox */}
                  <div onClick={() => toggleTask(t.id)} style={{ width: 22, height: 22, borderRadius: 6, border: "2px solid", borderColor: t.done ? "hsl(var(--green))" : PRIO_COLORS[t.priorite], background: t.done ? "hsl(var(--green))" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, transition: "all .2s" }}>
                    {t.done && <span className="check-pop" style={{ fontSize: 12, color: "white", fontWeight: 700 }}>✓</span>}
                  </div>
                  {/* Texte */}
                  <span style={{ flex: 1, fontSize: 13, color: t.done ? "hsl(var(--muted2))" : "hsl(var(--bark))", position: "relative", lineHeight: 1.5 }}>
                    {t.texte}
                    {t.done && <span style={{ position: "absolute", left: 0, top: "50%", height: "1.5px", background: "hsl(var(--muted))", width: "100%", display: "block", marginTop: "-0.75px", animation: "strike .35s cubic-bezier(.22,1,.36,1) forwards", borderRadius: 2 }} />}
                  </span>
                  {/* Badge priorité */}
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: PRIO_COLORS[t.priorite], flexShrink: 0, opacity: t.done ? 0.3 : 1 }} />
                  {/* Supprimer */}
                  <button onClick={() => delTask(t.id)} style={{ color: "hsl(var(--muted2))", padding: 4, opacity: 0.5, transition: "opacity .15s", display: "flex" }}
                    onMouseEnter={e => (e.currentTarget as HTMLElement).style.opacity = "1"}
                    onMouseLeave={e => (e.currentTarget as HTMLElement).style.opacity = "0.5"}>
                    <Ic d={IC.close} size={13} />
                  </button>
                </div>
              ))}

              {/* Ajouter une tâche */}
              <div style={{ display: "flex", gap: 7, marginTop: 6, alignItems: "flex-end" }}>
                <div style={{ flex: 1 }}>
                  <input placeholder={`Ajouter pour ${JOURS_TASKS[selectedJour]}…`} value={newTask}
                    onChange={e => setNewTask(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && addTask()}
                    style={{ fontSize: 13, padding: "9px 13px" }} />
                </div>
                {/* Priorité */}
                <select value={priorite} onChange={e => setPriorite(e.target.value as any)} style={{ fontSize: 11, padding: "9px 8px", width: "auto", border: `1.5px solid ${PRIO_COLORS[priorite]}55`, color: PRIO_COLORS[priorite] }}>
                  <option value="haute">🔴</option>
                  <option value="normale">🟡</option>
                  <option value="basse">⚪</option>
                </select>
                <button onClick={addTask} disabled={!newTask.trim()} style={{ padding: "9px 16px", borderRadius: 8, background: newTask.trim() ? TASK_COLORS[selectedJour % TASK_COLORS.length] : "hsl(var(--surface2))", color: newTask.trim() ? "white" : "hsl(var(--muted))", fontWeight: 700, fontSize: 15, transition: "all .18s" }}>+</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VUE LISTE */}
      {view === "list" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {JOURS_TASKS.map((jour, ji) => {
            const jTasks = tasks.filter(t => t.jour === ji);
            if (jTasks.length === 0) return null;
            const done = jTasks.filter(t => t.done).length;
            const pct = jTasks.length > 0 ? (done / jTasks.length) * 100 : 0;
            const isToday = ji === (new Date().getDay() + 6) % 7;
            return (
              <div key={ji} className="rise" style={{ background: "hsl(var(--surface))", border: "1.5px solid", borderColor: isToday ? "hsl(var(--honey))" : "hsl(var(--border))", borderRadius: 12, overflow: "hidden" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 16px", borderBottom: "1px solid hsl(var(--border))" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 10, height: 10, borderRadius: "50%", background: TASK_COLORS[ji % TASK_COLORS.length] }} />
                    <p style={{ fontWeight: 700, fontSize: 14, color: isToday ? "hsl(var(--honey))" : "hsl(var(--bark))" }}>{jour} {isToday ? "— Aujourd'hui" : ""}</p>
                  </div>
                  <span style={{ fontSize: 12, color: "hsl(var(--muted))" }}>{done}/{jTasks.length}</span>
                </div>
                <div style={{ height: 3, background: "hsl(var(--surface2))" }}>
                  <div style={{ height: "100%", width: `${pct}%`, background: TASK_COLORS[ji % TASK_COLORS.length], transition: "width .8s cubic-bezier(.22,1,.36,1)" }} />
                </div>
                <div style={{ padding: "10px 16px", display: "flex", flexDirection: "column", gap: 6 }}>
                  {jTasks.map((t, i) => (
                    <div key={t.id} className="rise" style={{ animationDelay: `${i * 0.04}s`, display: "flex", alignItems: "center", gap: 9 }}>
                      <div onClick={() => toggleTask(t.id)} style={{ width: 18, height: 18, borderRadius: 5, border: "2px solid", borderColor: t.done ? "hsl(var(--green))" : PRIO_COLORS[t.priorite], background: t.done ? "hsl(var(--green))" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, transition: "all .2s" }}>
                        {t.done && <span style={{ fontSize: 10, color: "white", fontWeight: 700 }}>✓</span>}
                      </div>
                      <span style={{ flex: 1, fontSize: 13, color: t.done ? "hsl(var(--muted2))" : "hsl(var(--foreground))", textDecoration: t.done ? "line-through" : "none", textDecorationColor: "hsl(var(--muted))" }}>{t.texte}</span>
                      <button onClick={() => delTask(t.id)} style={{ color: "hsl(var(--muted2))", padding: 3, display: "flex", opacity: 0.5 }} onMouseEnter={e => (e.currentTarget as HTMLElement).style.opacity = "1"} onMouseLeave={e => (e.currentTarget as HTMLElement).style.opacity = "0.5"}><Ic d={IC.close} size={12} /></button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
          {tasks.length === 0 && (
            <div style={{ textAlign: "center", padding: "72px 0", color: "hsl(var(--muted2))" }}>
              <div className="float" style={{ fontSize: 52, marginBottom: 14 }}>⭕</div>
              <p className="cg-i" style={{ fontSize: 18 }}>Aucune tâche encore.</p>
            </div>
          )}
          {/* Ajout rapide en vue liste */}
          <div className="rise s4" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 12, padding: "14px 16px" }}>
            <p style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 10 }}>Ajouter une tâche</p>
            <div style={{ display: "flex", gap: 7 }}>
              <select value={selectedJour} onChange={e => setSelectedJour(Number(e.target.value))} style={{ fontSize: 12, padding: "8px 10px", width: "auto" }}>
                {JOURS_TASKS.map((j, i) => <option key={i} value={i}>{j}</option>)}
              </select>
              <input placeholder="Nouvelle tâche…" value={newTask} onChange={e => setNewTask(e.target.value)} onKeyDown={e => e.key === "Enter" && addTask()} style={{ flex: 1, fontSize: 13 }} />
              <select value={priorite} onChange={e => setPriorite(e.target.value as any)} style={{ fontSize: 11, padding: "8px 8px", width: "auto" }}>
                <option value="haute">🔴</option>
                <option value="normale">🟡</option>
                <option value="basse">⚪</option>
              </select>
              <button onClick={addTask} disabled={!newTask.trim()} style={{ padding: "8px 16px", borderRadius: 8, background: "hsl(var(--honey))", color: "hsl(var(--background))", fontWeight: 700, fontSize: 14, transition: "all .18s", opacity: newTask.trim() ? 1 : 0.4 }}>+</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
