import { useState, useEffect } from "react";
import { db, auth } from "@/lib/storage";
import { citeDuJour, IC, AVATARS } from "@/lib/constants";
import { Btn, Ic, Field, PwdStrength } from "./BaseUI";
import { OrganicCanvas, GlitterCanvas } from "./Canvas";
import { useTheme } from "@/contexts/AppContext";

// ═══ LOGIN ═══
export const Login = ({ onLogin }: { onLogin: () => void }) => {
  const { theme } = useTheme();
  const isGirls = theme === "girls";
  const [mode, setMode] = useState<"loading" | "choose" | "login" | "register">("loading");
  const [pwd, setPwd] = useState("");
  const [cp, setCp] = useState("");
  const [err, setErr] = useState("");
  const [show, setShow] = useState(false);
  const cit = citeDuJour();

  useEffect(() => {
    // Si des comptes existent → choix, sinon → inscription directe
    setMode(auth.hasAnyAccount() ? "choose" : "register");
  }, []);

  const doLogin = async () => {
    if (!pwd) return setErr("Entre ton mot de passe.");
    const hash = await auth.tryLogin(pwd);
    if (hash) {
      db.setAccount(hash);
      onLogin();
    } else {
      setErr("Mot de passe incorrect. Pas de compte associé.");
    }
  };

  const doRegister = async () => {
    if (!pwd) return setErr("Choisis un mot de passe.");
    if (pwd.length < 4) return setErr("Mot de passe trop court (min. 4 caractères).");
    if (pwd !== cp) return setErr("Les mots de passe ne correspondent pas.");
    const hash = await auth.register(pwd);
    db.setAccount(hash);
    onLogin();
  };

  if (mode === "loading") return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", background: "hsl(var(--background))" }}>
      <div style={{ width: 28, height: 28, borderRadius: "50%", border: "2.5px solid hsl(var(--border2))", borderTopColor: "hsl(var(--honey))", animation: "spin 1s linear infinite" }} />
    </div>
  );

  const leftBg = isGirls
    ? "linear-gradient(160deg, hsl(340, 40%, 12%) 0%, hsl(340, 35%, 18%) 40%, hsl(350, 30%, 25%) 70%, hsl(340, 25%, 30%) 100%)"
    : "linear-gradient(160deg, #0a0704 0%, #1a1006 40%, #2a1c0e 70%, #3c2c1a 100%)";

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: "hsl(var(--background))", overflow: "hidden" }}>
      {/* Panneau gauche */}
      <div className="grain" style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", padding: "60px 56px", background: leftBg, position: "relative", overflow: "hidden" }}>
        {isGirls ? <GlitterCanvas /> : <OrganicCanvas />}
        <div className="rise" style={{ position: "relative" }}>
          <div className="float" style={{ fontSize: 36, marginBottom: 20, opacity: 0.55 }}>{isGirls ? "✨" : "🌿"}</div>
          <Ic d={IC.quote} size={26} color={isGirls ? "rgba(220,100,160,.28)" : "rgba(200,150,50,.28)"} />
          <p style={{ fontFamily: "'Cormorant Garamond',serif", fontStyle: "italic", fontSize: 24, color: isGirls ? "#f8d7e8" : "#f0e8d8", lineHeight: 1.8, marginTop: 14, marginBottom: 18, fontWeight: 400 }}>"{cit.text}"</p>
          <p style={{ color: isGirls ? "rgba(220,100,160,.65)" : "rgba(200,150,50,.65)", fontSize: 13, fontWeight: 500 }}>— {cit.auteur}</p>
          <div style={{ marginTop: 44, paddingTop: 24, borderTop: "1px solid rgba(255,255,255,.07)" }}>
            <p style={{ color: "rgba(240,232,216,.25)", fontSize: 13 }}>Ton OS personnel. Privé. Sécurisé.</p>
          </div>
        </div>
      </div>

      {/* Panneau droit */}
      <div style={{ width: 420, display: "flex", flexDirection: "column", justifyContent: "center", padding: "60px 48px", background: "hsl(var(--surface))" }}>
        <div className="rise" style={{ animationDelay: ".1s" }}>

          {/* CHOIX INITIAL */}
          {mode === "choose" && (
            <>
              <h1 className={isGirls ? "cg-i shimmer-text" : "cg-i"} style={{ fontSize: 32, color: isGirls ? undefined : "hsl(var(--bark))", marginBottom: 8, lineHeight: 1.2 }}>
                Bienvenue.
              </h1>
              <p style={{ color: "hsl(var(--muted))", fontSize: 14, marginBottom: 40 }}>C'est ton espace. Qu'est-ce que tu veux faire ?</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Btn onClick={() => { setMode("login"); setErr(""); setPwd(""); }} v="cta" full>
                  Se connecter
                </Btn>
                <Btn onClick={() => { setMode("register"); setErr(""); setPwd(""); setCp(""); }} full>
                  Créer un nouveau compte
                </Btn>
              </div>
            </>
          )}

          {/* CONNEXION */}
          {mode === "login" && (
            <>
              <h1 className={isGirls ? "cg-i shimmer-text" : "cg-i"} style={{ fontSize: 32, color: isGirls ? undefined : "hsl(var(--bark))", marginBottom: 8, lineHeight: 1.2 }}>
                Bon retour.
              </h1>
              <p style={{ color: "hsl(var(--muted))", fontSize: 14, marginBottom: 36 }}>Ton espace t'attend.</p>
              <Field label="Mot de passe">
                <div style={{ position: "relative" }}>
                  <input
                    autoFocus
                    type={show ? "text" : "password"}
                    placeholder="••••••••"
                    value={pwd}
                    onChange={e => { setPwd(e.target.value); setErr(""); }}
                    onKeyDown={e => e.key === "Enter" && doLogin()}
                  />
                  <button onClick={() => setShow(s => !s)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", color: "hsl(var(--muted2))" }}>
                    <Ic d={show ? IC.eyeoff : IC.eye} size={15} />
                  </button>
                </div>
              </Field>
              {err && <p style={{ color: "hsl(var(--destructive))", fontSize: 13, marginBottom: 12, marginTop: -6 }}>{err}</p>}
              <Btn onClick={doLogin} v="cta" full>Entrer</Btn>
              <button onClick={() => { setMode("choose"); setErr(""); setPwd(""); }} style={{ marginTop: 18, width: "100%", textAlign: "center", fontSize: 13, color: "hsl(var(--muted2))" }}>
                ← Retour
              </button>
            </>
          )}

          {/* INSCRIPTION */}
          {mode === "register" && (
            <>
              <h1 className={isGirls ? "cg-i shimmer-text" : "cg-i"} style={{ fontSize: 32, color: isGirls ? undefined : "hsl(var(--bark))", marginBottom: 8, lineHeight: 1.2 }}>
                Première fois ici.
              </h1>
              <p style={{ color: "hsl(var(--muted))", fontSize: 14, marginBottom: 36 }}>Crée ton accès privé. Retiens bien ton mot de passe — c'est ta seule clé.</p>
              <Field label="Choisis ton mot de passe">
                <input
                  autoFocus
                  type={show ? "text" : "password"}
                  placeholder="Quelque chose de solide"
                  value={pwd}
                  onChange={e => { setPwd(e.target.value); setErr(""); }}
                />
                <PwdStrength pwd={pwd} />
              </Field>
              <Field label="Confirme ton mot de passe">
                <input
                  type={show ? "text" : "password"}
                  placeholder="Répète le mot de passe"
                  value={cp}
                  onChange={e => { setCp(e.target.value); setErr(""); }}
                  onKeyDown={e => e.key === "Enter" && doRegister()}
                />
              </Field>
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "hsl(var(--muted))", marginBottom: 18, cursor: "pointer" }}>
                <input type="checkbox" checked={show} onChange={e => setShow(e.target.checked)} style={{ width: "auto" }} />
                Afficher le mot de passe
              </label>
              {err && <p style={{ color: "hsl(var(--destructive))", fontSize: 13, marginBottom: 12, marginTop: -6 }}>{err}</p>}
              <Btn onClick={doRegister} v="cta" full>Créer mon espace</Btn>
              {auth.hasAnyAccount() && (
                <button onClick={() => { setMode("choose"); setErr(""); setPwd(""); setCp(""); }} style={{ marginTop: 18, width: "100%", textAlign: "center", fontSize: 13, color: "hsl(var(--muted2))" }}>
                  ← Retour
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// ═══ PROFILE SETUP ═══
export const ProfileSetup = ({ onDone }: { onDone: (p: { prenom: string; avatar: string }) => void }) => {
  const { theme } = useTheme();
  const isGirls = theme === "girls";
  const [prenom, setPrenom] = useState("");
  const [avatar, setAvatar] = useState(isGirls ? "🦋" : "🌿");

  const save = async () => {
    if (!prenom.trim()) return;
    const p = { prenom: prenom.trim(), avatar };
    await db.set("user-profile", p);
    onDone(p);
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "hsl(var(--background))", padding: 20, position: "relative", overflow: "hidden" }}>
      {isGirls ? <GlitterCanvas style={{ opacity: 0.6 }} /> : <OrganicCanvas style={{ opacity: 0.5 }} />}
      <div className="rise" style={{ background: "hsl(var(--surface))", borderRadius: 18, padding: "40px 44px", maxWidth: 440, width: "100%", border: "1.5px solid hsl(var(--border))", boxShadow: "var(--sh-xl)", position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div className="breath" style={{ fontSize: 52, marginBottom: 14 }}>{avatar}</div>
          <h2 className="cg-i" style={{ fontSize: 28, color: "hsl(var(--bark))", marginBottom: 8 }}>Bienvenue.</h2>
          <p style={{ color: "hsl(var(--muted))", fontSize: 14 }}>Ton espace t'attend. Personnalise-le.</p>
        </div>
        <Field label="Ton prénom">
          <input autoFocus placeholder="Comment tu t'appelles ?" value={prenom} onChange={e => setPrenom(e.target.value)} onKeyDown={e => e.key === "Enter" && save()} style={{ textAlign: "center", fontSize: 16 }} />
        </Field>
        <Field label="Ton avatar">
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginTop: 4 }}>
            {AVATARS.map(em => (
              <button key={em} onClick={() => setAvatar(em)} style={{ fontSize: 24, padding: "8px 10px", borderRadius: 8, background: avatar === em ? "hsla(var(--honey), 0.1)" : "transparent", border: avatar === em ? "1.5px solid hsl(var(--honey))" : "1.5px solid transparent", transform: avatar === em ? "scale(1.2)" : "scale(1)", transition: "all .18s" }}>{em}</button>
            ))}
          </div>
        </Field>
        <Btn onClick={save} full disabled={!prenom.trim()}>C'est parti ✦</Btn>
      </div>
    </div>
  );
};
