import { useState, useEffect, useCallback } from "react";
import { db } from "@/lib/storage";
import { NAV_GROUPS, IC } from "@/lib/constants";
import { Ic, XpBar, Toasts, LevelUpCelebration, useConfirm } from "./BaseUI";
import { OrganicCanvas, GlitterCanvas } from "./Canvas";
import { Login, ProfileSetup } from "./Auth";
import { Home } from "./Home";
import { Dashboard, Agenda, Journal, Habitudes, Suivi, Library, CitationsPage, Videos, Tasks } from "./Pages";
import { useTheme, useXP, useToast, useLevelUp } from "@/contexts/AppContext";

// ═══ POMODORO — Timer discret ═══
const PomodoroWidget = () => {
  const { addXP } = useXP();
  const WORK = 25 * 60, BREAK = 5 * 60;
  const [open, setOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [time, setTime] = useState(WORK);
  const [mode, setMode] = useState<"work" | "break">("work");

  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => setTime(t => {
      if (t <= 1) {
        clearInterval(iv); setRunning(false);
        if (mode === "work") { addXP(30, "Pomodoro ✓", "pomo"); setMode("break"); setTime(BREAK); }
        else { setMode("work"); setTime(WORK); }
        return 0;
      }
      return t - 1;
    }), 1000);
    return () => clearInterval(iv);
  }, [running, mode, addXP]);

  const mm = Math.floor(time / 60).toString().padStart(2, "0");
  const ss = (time % 60).toString().padStart(2, "0");
  const pct = mode === "work" ? 1 - time / WORK : 1 - time / BREAK;

  // Bouton discret en bas à droite
  return (
    <div style={{ position: "fixed", bottom: 20, right: 20, zIndex: 900 }}>
      {open ? (
        <div className="rise" style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 14, padding: "14px 16px", width: 180, boxShadow: "var(--sh-xl)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <p style={{ fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: ".06em", color: mode === "work" ? "hsl(var(--honey))" : "hsl(var(--green))" }}>{mode === "work" ? "⏱ Focus" : "☕ Pause"}</p>
            <button onClick={() => setOpen(false)} style={{ fontSize: 12, color: "hsl(var(--muted2))", padding: 2 }}>✕</button>
          </div>
          {/* Progress ring mini */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <svg width={36} height={36} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
              <circle cx={18} cy={18} r={14} fill="none" stroke="hsl(var(--surface2))" strokeWidth={3} />
              <circle cx={18} cy={18} r={14} fill="none" stroke={mode === "work" ? "hsl(var(--honey))" : "hsl(var(--green))"} strokeWidth={3} strokeDasharray={88} strokeDashoffset={88 * (1 - pct)} strokeLinecap="round" style={{ transition: "stroke-dashoffset 1s linear" }} />
            </svg>
            <span className="mono" style={{ fontSize: 22, fontWeight: 500, color: "hsl(var(--foreground))" }}>{mm}:{ss}</span>
          </div>
          <div style={{ display: "flex", gap: 5 }}>
            <button onClick={() => setRunning(r => !r)} style={{ flex: 1, padding: "7px 0", borderRadius: 6, background: running ? "hsl(var(--surface2))" : "hsl(var(--honey))", color: running ? "hsl(var(--foreground))" : "hsl(var(--background))", fontSize: 12, fontWeight: 600, transition: "all .15s" }}>{running ? "Pause" : "Start"}</button>
            <button onClick={() => { setTime(WORK); setMode("work"); setRunning(false); }} style={{ padding: "7px 10px", borderRadius: 6, background: "hsl(var(--surface2))", fontSize: 12, color: "hsl(var(--muted))", transition: "all .15s" }}>↺</button>
          </div>
        </div>
      ) : (
        <button onClick={() => setOpen(true)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 12px", borderRadius: 99, background: running ? "hsl(var(--honey))" : "hsl(var(--surface))", border: "1.5px solid", borderColor: running ? "hsl(var(--honey))" : "hsl(var(--border))", color: running ? "hsl(var(--background))" : "hsl(var(--muted))", fontSize: 12, fontWeight: running ? 600 : 400, boxShadow: "var(--sh-sm)", transition: "all .2s" }}>
          <span style={{ fontSize: 14 }}>⏱</span>
          {running ? <span className="mono">{mm}:{ss}</span> : <span>Focus</span>}
        </button>
      )}
    </div>
  );
};

// ═══ MAIN SHELL ═══
export const AppShell = () => {
  const { theme, cycleTheme } = useTheme();
  const { xp, level } = useXP();
  const { toasts } = useToast();
  const { levelUpAnim, clearLevelUp } = useLevelUp();
  const isGirls = theme === "girls";

  const [auth, setAuth] = useState(false);
  const [page, setPage] = useState("home");
  const [profile, setProfile] = useState<{ prenom: string; avatar: string } | null>(null);
  const [profileReady, setProfileReady] = useState(false);

  useEffect(() => {
    if (auth) {
      db.get("user-profile").then((p: any) => { setProfile(p); setProfileReady(true); });
    }
  }, [auth]);

  // Cmd+K shortcut placeholder
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if ((e.metaKey || e.ctrlKey) && e.key === "k") e.preventDefault(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);

  const themeIcon = theme === "light" ? IC.moon : theme === "dark" ? IC.heart : IC.sun;
  const themeLabel = theme === "light" ? "Dark" : theme === "dark" ? "Girls ✨" : "Light";

  if (!auth) return <Login onLogin={() => setAuth(true)} />;
  if (profileReady && !profile) return <ProfileSetup onDone={p => setProfile(p)} />;
  if (!profileReady || !profile) return <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh" }}><div style={{ width: 28, height: 28, borderRadius: "50%", border: "2.5px solid hsl(var(--border2))", borderTopColor: "hsl(var(--honey))", animation: "spin 1s linear infinite" }} /></div>;

  return (
    <>
      <div style={{ display: "flex", height: "100vh", overflow: "hidden" }}>
        {/* SIDEBAR */}
        <aside style={{ width: 228, background: "hsl(var(--sidebar-bg))", borderRight: "1.5px solid hsl(var(--sidebar-border))", display: "flex", flexDirection: "column", padding: "18px 12px", flexShrink: 0, position: "relative", overflow: "hidden", transition: "background .4s" }}>
          {isGirls ? <GlitterCanvas style={{ opacity: 0.4 }} /> : <OrganicCanvas style={{ opacity: 0.5 }} />}

          {/* Profile */}
          <div style={{ paddingLeft: 6, marginBottom: 16, position: "relative" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 8 }}>
              <div className="float" style={{ fontSize: 26, opacity: 0.8, flexShrink: 0 }}>{profile.avatar}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h1 className={isGirls ? "cg-i shimmer-text" : "cg-i"} style={{ fontSize: 15, fontWeight: 500, color: isGirls ? undefined : "hsl(var(--bark))", lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{profile.prenom}</h1>
                <XpBar xp={xp} level={level} compact />
              </div>
            </div>
          </div>

          {/* Theme toggle */}
          <div style={{ display: "flex", gap: 5, marginBottom: 14, position: "relative" }}>
            <button onClick={cycleTheme} style={{ flex: 1, display: "flex", alignItems: "center", gap: 7, padding: "7px 10px", borderRadius: 7, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--surface))", color: "hsl(var(--muted))", fontSize: 12, transition: "all .15s" }}>
              <Ic d={themeIcon} size={14} /><span>{themeLabel}</span>
            </button>
          </div>

          {/* Nav */}
          <nav style={{ display: "flex", flexDirection: "column", flex: 1, overflow: "auto", position: "relative" }}>
            {NAV_GROUPS.map(group => (
              <div key={group.label} style={{ marginBottom: 12 }}>
                <p style={{ fontSize: 9, fontWeight: 700, color: "hsl(var(--muted2))", textTransform: "uppercase", letterSpacing: ".1em", paddingLeft: 8, marginBottom: 4 }}>{group.label}</p>
                {group.items.map(n => {
                  const active = page === n.id;
                  return (
                    <button key={n.id} onClick={() => setPage(n.id)} style={{ background: active ? "hsla(var(--honey), 0.1)" : "transparent", color: active ? "hsl(var(--honey))" : "hsl(var(--muted))", border: active ? "1.5px solid hsla(var(--honey), 0.2)" : "1.5px solid transparent", borderRadius: 7, padding: "8px 11px", textAlign: "left", display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: active ? 600 : 400, transition: "all .15s", width: "100%", marginBottom: 1 }}>
                      <span style={{ fontSize: 14 }}>{n.emoji}</span>{n.label}
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>

          {/* Footer */}
          <div style={{ position: "relative", borderTop: "1px solid hsl(var(--border))", paddingTop: 10 }}>
            <button onClick={() => { setAuth(false); setProfile(null); setProfileReady(false); }} style={{ width: "100%", textAlign: "left", padding: "8px 11px", borderRadius: 7, fontSize: 12, color: "hsl(var(--muted2))", display: "flex", alignItems: "center", gap: 7 }}>
              <Ic d={IC.logout} size={13} />Déconnexion
            </button>
          </div>
        </aside>

        {/* MAIN */}
        <main style={{ flex: 1, overflow: "auto", padding: "36px 44px", background: "hsl(var(--background))", transition: "background .4s" }}>
          <div style={{ maxWidth: 820, margin: "0 auto" }} key={page} className="page-enter">
            {page === "home" && <Home onNav={setPage} profile={profile} />}
            {page === "dashboard" && <Dashboard onNav={setPage} />}
            {page === "agenda" && <Agenda />}
            {page === "journal" && <Journal />}
            {page === "habitudes" && <Habitudes />}
            {page === "suivi" && <Suivi />}
            {page === "library" && <Library />}
            {page === "citations" && <CitationsPage />}
            {page === "videos" && <Videos />}
            {page === "tasks" && <Tasks />}
          </div>
        </main>
      </div>

      <PomodoroWidget />
      {levelUpAnim && <LevelUpCelebration level={levelUpAnim} onDone={clearLevelUp} />}
      <Toasts toasts={toasts} />
    </>
  );
};
