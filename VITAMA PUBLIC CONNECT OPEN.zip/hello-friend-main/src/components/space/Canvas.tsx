import { useRef, useEffect } from "react";
import { useTheme } from "@/contexts/AppContext";

// ═══ ORGANIC CANVAS — floating orbs ═══
export const OrganicCanvas = ({ style = {} }: { style?: React.CSSProperties }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const fr = useRef<number>(0);
  const { theme } = useTheme();

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const resize = () => { c.width = c.offsetWidth; c.height = c.offsetHeight; };
    resize();
    const LIGHT: number[][] = [[150, 100, 12], [61, 82, 40], [58, 38, 16], [207, 156, 58], [90, 66, 38]];
    const DARK: number[][] = [[212, 160, 48], [122, 184, 84], [180, 120, 60], [80, 140, 100], [160, 100, 40]];
    const GIRLS: number[][] = [[220, 100, 160], [180, 80, 140], [200, 120, 180], [240, 140, 200], [160, 60, 120]];
    const COLORS = theme === "dark" ? DARK : theme === "girls" ? GIRLS : LIGHT;
    const orbs = Array.from({ length: 9 }, (_, i) => ({
      x: Math.random() * c.width, y: Math.random() * c.height,
      r: 60 + Math.random() * 120, vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.25,
      phase: Math.random() * Math.PI * 2, speed: 0.0025 + Math.random() * 0.004,
      color: COLORS[i % COLORS.length], alpha: theme === "dark" ? 0.06 + Math.random() * 0.05 : 0.04 + Math.random() * 0.04,
    }));
    const ctx = c.getContext("2d")!;
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      orbs.forEach(o => {
        o.phase += o.speed; o.x += o.vx + Math.sin(o.phase) * 0.25; o.y += o.vy + Math.cos(o.phase * 0.7) * 0.2;
        if (o.x < -o.r) o.x = c.width + o.r; if (o.x > c.width + o.r) o.x = -o.r;
        if (o.y < -o.r) o.y = c.height + o.r; if (o.y > c.height + o.r) o.y = -o.r;
        const g = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, o.r);
        const [r, g_, b] = o.color;
        g.addColorStop(0, `rgba(${r},${g_},${b},${o.alpha})`);
        g.addColorStop(0.55, `rgba(${r},${g_},${b},${o.alpha * 0.3})`);
        g.addColorStop(1, `rgba(${r},${g_},${b},0)`);
        ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill();
      });
      fr.current = requestAnimationFrame(draw);
    };
    draw();
    const ro = new ResizeObserver(resize); ro.observe(c);
    return () => { cancelAnimationFrame(fr.current); ro.disconnect(); };
  }, [theme]);

  return <canvas ref={ref} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", ...style }} />;
};

// ═══ GLITTER CANVAS — Girls Mode sparkles ═══
export const GlitterCanvas = ({ style = {} }: { style?: React.CSSProperties }) => {
  const ref = useRef<HTMLCanvasElement>(null);
  const fr = useRef<number>(0);

  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const resize = () => { c.width = c.offsetWidth; c.height = c.offsetHeight; };
    resize();

    interface Particle {
      x: number; y: number; size: number; speed: number; opacity: number;
      phase: number; phaseSpeed: number; color: string;
    }

    const particles: Particle[] = Array.from({ length: 35 }, () => ({
      x: Math.random() * c.width,
      y: Math.random() * c.height,
      size: 1 + Math.random() * 3,
      speed: 0.15 + Math.random() * 0.3,
      opacity: 0,
      phase: Math.random() * Math.PI * 2,
      phaseSpeed: 0.01 + Math.random() * 0.02,
      color: [`rgba(220,100,160,`, `rgba(240,180,200,`, `rgba(200,140,220,`, `rgba(255,200,220,`][Math.floor(Math.random() * 4)],
    }));

    const ctx = c.getContext("2d")!;
    const draw = () => {
      ctx.clearRect(0, 0, c.width, c.height);
      particles.forEach(p => {
        p.phase += p.phaseSpeed;
        p.y -= p.speed;
        p.x += Math.sin(p.phase) * 0.5;
        p.opacity = 0.3 + Math.sin(p.phase * 2) * 0.3;
        if (p.y < -10) { p.y = c.height + 10; p.x = Math.random() * c.width; }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${p.opacity})`;
        ctx.fill();
        // Glow
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 2.5, 0, Math.PI * 2);
        ctx.fillStyle = `${p.color}${p.opacity * 0.15})`;
        ctx.fill();
      });
      fr.current = requestAnimationFrame(draw);
    };
    draw();
    const ro = new ResizeObserver(resize); ro.observe(c);
    return () => { cancelAnimationFrame(fr.current); ro.disconnect(); };
  }, []);

  return <canvas ref={ref} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", ...style }} />;
};
