import { useRef, useEffect, useState, useCallback, type ReactNode } from "react";
import { useTheme } from "@/contexts/AppContext";
import { IC, xpForLevel, xpToNext, getLevelName } from "@/lib/constants";

// ═══ ICON ═══
export const Ic = ({ d, size = 17, color = "currentColor", sw = 1.7 }: { d: string; size?: number; color?: string; sw?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}><path d={d} /></svg>
);

// ═══ BUTTON ═══
type BtnVariant = "honey" | "cta" | "olive" | "ghost" | "danger" | "bark" | "girls";
export const Btn = ({ children, onClick, v = "honey", sm, full, disabled }: { children: ReactNode; onClick?: () => void; v?: BtnVariant; sm?: boolean; full?: boolean; disabled?: boolean }) => {
  const { theme } = useTheme();
  const isGirls = theme === "girls";
  const vs: Record<string, React.CSSProperties> = {
    honey: { background: "hsl(var(--honey))", color: "hsl(var(--background))", boxShadow: "var(--sh-h)" },
    cta: { background: "hsl(var(--cta))", color: "#f8f2e6", boxShadow: "0 6px 20px hsla(var(--cta), 0.3)" },
    olive: { background: "hsl(var(--olive))", color: "hsl(var(--background))", boxShadow: "var(--sh-o)" },
    ghost: { background: "transparent", color: "hsl(var(--muted))", border: "1.5px solid hsl(var(--border))" },
    danger: { background: "transparent", color: "hsl(var(--destructive))", border: "1.5px solid hsla(var(--destructive), 0.3)" },
    bark: { background: "hsl(var(--bark2))", color: "hsl(var(--background))", boxShadow: "var(--sh-md)" },
    girls: { background: "linear-gradient(135deg, hsl(340, 65%, 55%), hsl(350, 60%, 65%))", color: "#fff", boxShadow: "var(--sh-h)" },
  };
  const effectiveV = isGirls && (v === "honey" || v === "cta") ? "girls" : v;
  return (
    <button onClick={onClick} disabled={disabled} style={{ ...vs[effectiveV], display: "inline-flex", alignItems: "center", gap: 7, borderRadius: 6, fontSize: sm ? 13 : 14, fontWeight: 600, padding: sm ? "7px 14px" : "10px 22px", width: full ? "100%" : undefined, justifyContent: full ? "center" : undefined, transition: "all .18s cubic-bezier(.22,1,.36,1)", fontFamily: "'DM Sans',sans-serif", opacity: disabled ? 0.4 : 1, pointerEvents: disabled ? "none" : "auto" }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.filter = "brightness(.88)"; (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.filter = "none"; (e.currentTarget as HTMLElement).style.transform = "none"; }}
    >{children}</button>
  );
};

// ═══ MODAL ═══
export const Modal = ({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) => (
  <div className="appear" onClick={e => e.target === e.currentTarget && onClose()} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", backdropFilter: "blur(10px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 }}>
    <div className="rise" style={{ background: "hsl(var(--surface))", borderRadius: 14, padding: 32, width: "100%", maxWidth: wide ? 720 : 460, border: "1.5px solid hsl(var(--border))", boxShadow: "var(--sh-xl)", maxHeight: "92vh", overflowY: "auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
        <h3 className="cg-i" style={{ fontSize: 21, color: "hsl(var(--bark))", fontWeight: 500 }}>{title}</h3>
        <button onClick={onClose} style={{ color: "hsl(var(--muted2))", padding: 4, transition: "color .15s" }}><Ic d={IC.close} /></button>
      </div>
      {children}
    </div>
  </div>
);

// ═══ FIELD / LABEL ═══
export const Lbl = ({ t }: { t: string }) => <p style={{ fontSize: 11, fontWeight: 600, color: "hsl(var(--muted))", textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 6 }}>{t}</p>;
export const Field = ({ label, children, mb = 14 }: { label?: string; children: ReactNode; mb?: number }) => <div style={{ marginBottom: mb }}>{label && <Lbl t={label} />}{children}</div>;

// ═══ RING ═══
export const Ring = ({ value = 0, max = 100, size = 64, stroke = 5, color = "hsl(var(--olive))", label, sub, pulse }: { value?: number; max?: number; size?: number; stroke?: number; color?: string; label?: string | number; sub?: string; pulse?: boolean }) => {
  const [disp, setDisp] = useState(0);
  useEffect(() => { const t = setTimeout(() => setDisp(value), 80); return () => clearTimeout(t); }, [value]);
  const r = (size - stroke * 2) / 2, circ = 2 * Math.PI * r, pct = max ? Math.min(disp / max, 1) : 0;
  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="hsl(var(--surface2))" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={circ} strokeDashoffset={circ * (1 - pct)} strokeLinecap="round" style={{ transition: "stroke-dashoffset .9s cubic-bezier(.22,1,.36,1)" }} />
      </svg>
      {label != null && <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <span style={{ fontSize: size * 0.18, fontWeight: 700, color: "hsl(var(--foreground))", lineHeight: 1.1 }}>{label}</span>
        {sub && <span style={{ fontSize: size * 0.12, color: "hsl(var(--muted))", marginTop: 1 }}>{sub}</span>}
      </div>}
    </div>
  );
};

// ═══ XP BAR ═══
export const XpBar = ({ xp, level, compact }: { xp: number; level: number; compact?: boolean }) => {
  const from = xpForLevel(level), to = xpToNext(level);
  const pct = to > from ? Math.round((xp - from) / (to - from) * 100) : 100;
  if (compact) return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ flex: 1, height: 3, background: "hsl(var(--surface2))", borderRadius: 2, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: "hsl(var(--honey))", borderRadius: 2, transition: "width .8s cubic-bezier(.22,1,.36,1)" }} />
      </div>
      <span style={{ fontSize: 10, color: "hsl(var(--honey))", fontWeight: 600, whiteSpace: "nowrap" }}>Niv.{level}</span>
    </div>
  );
  return (
    <div style={{ background: "hsl(var(--surface2))", borderRadius: 8, padding: "10px 14px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: "hsl(var(--honey))" }}>Niveau {level} — {getLevelName(level)}</span>
        <span style={{ fontSize: 11, color: "hsl(var(--muted))" }}>{xp - from} / {to - from} XP</span>
      </div>
      <div style={{ height: 5, background: "hsl(var(--surface3))", borderRadius: 3, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, background: "linear-gradient(90deg, hsl(var(--honey)), hsl(var(--honey-lt)))", borderRadius: 3, transition: "width .8s cubic-bezier(.22,1,.36,1)" }} />
      </div>
    </div>
  );
};

// ═══ STAT CARD ═══
export const StatCard = ({ emoji, val, label, color, to, delay, onNav }: { emoji: string; val: number; label: string; color: string; to?: string; delay: number; onNav?: (p: string) => void }) => {
  const [n, setN] = useState(0);
  useEffect(() => {
    let f: number;
    const t0 = performance.now();
    const tick = (now: number) => { const p = Math.min((now - t0) / 900, 1); setN(Math.round((1 - Math.pow(1 - p, 3)) * val)); if (p < 1) f = requestAnimationFrame(tick); };
    f = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(f);
  }, [val]);
  return (
    <div className={`rise s${delay}`} onClick={() => to && onNav?.(to)} style={{ background: "hsl(var(--surface))", border: "1.5px solid hsl(var(--border))", borderRadius: 10, padding: "16px 18px", cursor: to ? "pointer" : "default", transition: "all .22s cubic-bezier(.22,1,.36,1)", flex: 1, minWidth: 110, boxShadow: "var(--sh-xs)" }}
      onMouseEnter={e => { if (to) { (e.currentTarget as HTMLElement).style.borderColor = color; (e.currentTarget as HTMLElement).style.transform = "translateY(-3px)"; (e.currentTarget as HTMLElement).style.boxShadow = "var(--sh-md)"; } }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "hsl(var(--border))"; (e.currentTarget as HTMLElement).style.transform = "none"; (e.currentTarget as HTMLElement).style.boxShadow = "var(--sh-xs)"; }}>
      <div style={{ fontSize: 20, marginBottom: 8 }}>{emoji}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color, lineHeight: 1 }}>{n}</div>
      <div style={{ fontSize: 11, color: "hsl(var(--muted))", marginTop: 5 }}>{label}</div>
    </div>
  );
};

// ═══ PWD STRENGTH ═══
export const PwdStrength = ({ pwd }: { pwd: string }) => {
  if (!pwd) return null;
  const c = [pwd.length >= 8, pwd.length >= 12, /[A-Z]/.test(pwd) && /[a-z]/.test(pwd), /[0-9]/.test(pwd), /[^A-Za-z0-9]/.test(pwd)];
  const s = c.filter(Boolean).length;
  const L = ["", "Très faible", "Faible", "Moyen", "Fort", "Excellent"];
  const C = ["", "hsl(var(--destructive))", "#c07020", "hsl(var(--honey))", "hsl(var(--olive))", "hsl(var(--green))"];
  const W = ["0%", "20%", "40%", "65%", "85%", "100%"];
  return (
    <div style={{ marginTop: 7 }}>
      <div style={{ height: 3, background: "hsl(var(--surface2))", borderRadius: 2, overflow: "hidden", marginBottom: 4 }}>
        <div style={{ height: "100%", width: W[s], background: C[s], borderRadius: 2, transition: "width .45s cubic-bezier(.22,1,.36,1), background .3s" }} />
      </div>
      {s > 0 && <p style={{ fontSize: 11, color: C[s], fontWeight: 600 }}>{L[s]}</p>}
    </div>
  );
};

// ═══ TOASTS ═══
export const Toasts = ({ toasts }: { toasts: { id: number; msg: string; type: string }[] }) => (
  <div style={{ position: "fixed", bottom: 28, right: 28, display: "flex", flexDirection: "column", gap: 8, zIndex: 3000, pointerEvents: "none" }}>
    {toasts.map(t => (
      <div key={t.id} style={{ background: t.type === "error" ? "hsl(var(--destructive))" : t.type === "warn" ? "hsl(var(--honey))" : t.type === "xp" ? "hsl(var(--olive))" : "hsl(var(--bark2))", color: "hsl(var(--background))", padding: "11px 18px", borderRadius: 8, fontSize: 13, fontWeight: 500, boxShadow: "var(--sh-lg)", display: "flex", alignItems: "center", gap: 9, minWidth: 200, animation: "toast-in .3s cubic-bezier(.22,1,.36,1) both" }}>
        <span style={{ fontSize: 15 }}>{t.type === "error" ? "✗" : t.type === "warn" ? "⚡" : t.type === "xp" ? "⭐" : "✓"}</span>{t.msg}
      </div>
    ))}
  </div>
);

// ═══ LEVEL UP CELEBRATION ═══
export const LevelUpCelebration = ({ level, onDone }: { level: number; onDone: () => void }) => {
  const confetti = Array.from({ length: 16 }, (_, i) => ({
    x: 20 + Math.random() * 60,
    delay: Math.random() * 0.6,
    color: ["hsl(var(--honey))", "hsl(var(--olive))", "hsl(var(--green))", "hsl(var(--honey-lt))"][i % 4],
    size: 6 + Math.random() * 8,
  }));
  useEffect(() => { const t = setTimeout(onDone, 2600); return () => clearTimeout(t); }, [onDone]);
  return (
    <div className="appear" style={{ position: "fixed", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 4000, pointerEvents: "none" }}>
      <div style={{ position: "relative", textAlign: "center" }}>
        {confetti.map((c, i) => <div key={i} style={{ position: "absolute", left: `${c.x}%`, top: "-20px", width: c.size, height: c.size, borderRadius: "50%", background: c.color, animation: `confetti-fall ${0.8 + Math.random() * 0.8}s ${c.delay}s ease-in both`, transform: "translateX(-50%)" }} />)}
        <div style={{ background: "hsl(var(--surface))", border: "2px solid hsl(var(--honey))", borderRadius: 20, padding: "32px 48px", boxShadow: "var(--sh-xl)", animation: "level-up .5s cubic-bezier(.22,1,.36,1) both" }}>
          <div style={{ fontSize: 52, marginBottom: 12 }}>🏆</div>
          <p className="cg-i" style={{ fontSize: 28, color: "hsl(var(--honey))", marginBottom: 4 }}>Niveau {level} !</p>
          <p style={{ fontSize: 14, color: "hsl(var(--muted))", fontWeight: 500 }}>{getLevelName(level)}</p>
        </div>
      </div>
    </div>
  );
};

// ═══ CONFIRM HOOK ═══
export const useConfirm = (): [((msg: string, danger?: boolean) => Promise<boolean>), ReactNode] => {
  const [cfg, setCfg] = useState<{ msg: string; danger: boolean; res: (v: boolean) => void } | null>(null);
  const ask = useCallback((msg: string, danger = true) => new Promise<boolean>(res => setCfg({ msg, danger, res })), []);
  const Dialog = cfg ? (
    <div className="appear" onClick={e => e.target === e.currentTarget && (cfg.res(false), setCfg(null))} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", backdropFilter: "blur(10px)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1200, padding: 20 }}>
      <div className="rise" style={{ background: "hsl(var(--surface))", borderRadius: 14, padding: "28px 32px", maxWidth: 360, width: "100%", border: "1.5px solid hsl(var(--border))", boxShadow: "var(--sh-xl)" }}>
        <p style={{ fontSize: 15, color: "hsl(var(--foreground))", marginBottom: 22, lineHeight: 1.65 }}>{cfg.msg}</p>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <Btn v="ghost" sm onClick={() => { cfg.res(false); setCfg(null); }}>Annuler</Btn>
          <Btn v={cfg.danger ? "danger" : "honey"} sm onClick={() => { cfg.res(true); setCfg(null); }}>Confirmer</Btn>
        </div>
      </div>
    </div>
  ) : null;
  return [ask, Dialog];
};
