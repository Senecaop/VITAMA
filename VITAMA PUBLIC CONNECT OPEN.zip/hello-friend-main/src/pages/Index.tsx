import { AppProvider } from "@/contexts/AppContext";
import { AppShell } from "@/components/space/Shell";

const Index = () => (
  <AppProvider>
    <AppShell />
  </AppProvider>
);

export default Index;
