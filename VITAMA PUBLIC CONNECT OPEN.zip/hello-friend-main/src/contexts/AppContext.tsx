import { createContext, useContext, useState, useCallback, useEffect, useRef, type ReactNode } from "react";
import { db } from "@/lib/storage";
import { getLevel, getAutoTheme } from "@/lib/constants";

// ═══ THEME CONTEXT ═══
type ThemeType = "light" | "dark" | "girls";
interface ThemeCtxType { theme: ThemeType; setTheme: (t: ThemeType) => void; cycleTheme: () => void; }
const ThemeCtx = createContext<ThemeCtxType>({ theme: "light", setTheme: () => {}, cycleTheme: () => {} });
export const useTheme = () => useContext(ThemeCtx);

// ═══ XP CONTEXT — Smart system with debounce + cooldown ═══
interface XpCtxType { xp: number; level: number; addXP: (amount: number, msg?: string, actionKey?: string) => void; }
const XpCtx = createContext<XpCtxType>({ xp: 0, level: 1, addXP: () => {} });
export const useXP = () => useContext(XpCtx);

// ═══ TOAST CONTEXT ═══
export interface Toast { id: number; msg: string; type: "success" | "error" | "warn" | "xp"; }
interface ToastCtxType { toasts: Toast[]; showToast: (msg: string, type?: Toast["type"]) => void; }
const ToastCtx = createContext<ToastCtxType>({ toasts: [], showToast: () => {} });
export const useToast = () => useContext(ToastCtx);

// ═══ LEVEL UP ═══
interface LevelUpCtxType { levelUpAnim: number | null; clearLevelUp: () => void; }
const LevelUpCtx = createContext<LevelUpCtxType>({ levelUpAnim: null, clearLevelUp: () => {} });
export const useLevelUp = () => useContext(LevelUpCtx);

// ═══ PROVIDER ═══
export function AppProvider({ children }: { children: ReactNode }) {
  // Theme
  const [theme, setThemeState] = useState<ThemeType>(() => {
    const saved = localStorage.getItem("space-theme-override");
    if (saved === "girls" || saved === "light" || saved === "dark") return saved;
    return getAutoTheme() as ThemeType;
  });

  const setTheme = useCallback((t: ThemeType) => {
    setThemeState(t);
    localStorage.setItem("space-theme-override", t);
  }, []);

  const cycleTheme = useCallback(() => {
    setThemeState(prev => {
      const next = prev === "light" ? "dark" : prev === "dark" ? "girls" : "light";
      localStorage.setItem("space-theme-override", next);
      return next;
    });
  }, []);

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);
  const showToast = useCallback((msg: string, type: Toast["type"] = "success") => {
    const id = Date.now();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2800);
  }, []);

  // XP — Smart system
  const [xpData, setXpData] = useState({ xp: 0, level: 1 });
  const [levelUpAnim, setLevelUpAnim] = useState<number | null>(null);
  const cooldowns = useRef<Map<string, number>>(new Map());
  const xpBatch = useRef<{ amount: number; timer: ReturnType<typeof setTimeout> | null }>({ amount: 0, timer: null });

  useEffect(() => {
    db.get("xp-data").then(x => setXpData(x || { xp: 0, level: 1 }));
  }, []);

  const addXP = useCallback((amount: number, msg?: string, actionKey?: string) => {
    // Cooldown check — same action type blocked for 30s
    if (actionKey) {
      const lastTime = cooldowns.current.get(actionKey) || 0;
      if (Date.now() - lastTime < 30000) return; // 30s cooldown
      cooldowns.current.set(actionKey, Date.now());
    }

    // Batch XP: accumulate within 500ms window
    xpBatch.current.amount += amount;
    if (xpBatch.current.timer) clearTimeout(xpBatch.current.timer);

    xpBatch.current.timer = setTimeout(() => {
      const batchAmount = xpBatch.current.amount;
      xpBatch.current.amount = 0;

      setXpData(prev => {
        const nxp = prev.xp + batchAmount;
        const nl = getLevel(nxp);
        const lvlUp = nl > prev.level;
        const next = { xp: nxp, level: nl };
        db.set("xp-data", next);
        if (lvlUp) setLevelUpAnim(nl);
        return next;
      });

      if (msg) showToast(`+${batchAmount} XP`, "xp");
    }, 500);
  }, [showToast]);

  const clearLevelUp = useCallback(() => setLevelUpAnim(null), []);

  return (
    <ThemeCtx.Provider value={{ theme, setTheme, cycleTheme }}>
      <XpCtx.Provider value={{ xp: xpData.xp, level: xpData.level, addXP }}>
        <ToastCtx.Provider value={{ toasts, showToast }}>
          <LevelUpCtx.Provider value={{ levelUpAnim, clearLevelUp }}>
            <div data-theme={theme} style={{ minHeight: "100vh" }}>
              {children}
            </div>
          </LevelUpCtx.Provider>
        </ToastCtx.Provider>
      </XpCtx.Provider>
    </ThemeCtx.Provider>
  );
}
